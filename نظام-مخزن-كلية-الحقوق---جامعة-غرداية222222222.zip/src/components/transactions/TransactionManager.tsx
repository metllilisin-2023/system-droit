import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  PlusCircle, 
  MinusCircle, 
  Search, 
  ChevronDown, 
  Trash2, 
  Printer, 
  Send, 
  Calendar,
  AlertCircle
} from 'lucide-react';
import SignatureCanvas from 'react-signature-canvas';
import { InventoryItem, InboundLog, OutboundLog, Supplier, DeliveryType, Category, Unit } from '../../types';
import { useInventoryStore } from '../../store/inventoryStore';
import { cn, parseDateStr } from '../../lib/utils';
import { useUIStore } from '../../store/uiStore';
import { BrandingHeader } from '../ui/BrandingHeader';

// Searchable Item Selector Component
export const SearchableItemSelector: React.FC<{
  items: InventoryItem[],
  value: string,
  onChange: (itemId: string) => void,
  placeholder?: string
}> = ({ items, value, onChange, placeholder }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedItem = items.find(i => i.id === value);
  const filteredItems = useMemo(() => {
    const s = search.toLowerCase();
    return items.filter(item => 
      item.name.toLowerCase().includes(s) ||
      item.barcode.toLowerCase().includes(s) ||
      item.category.toLowerCase().includes(s)
    ).slice(0, 10);
  }, [items, search]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={containerRef}>
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl cursor-pointer flex justify-between items-center transition-all hover:bg-white hover:border-indigo-300"
      >
        <span className={cn("text-sm truncate font-bold", selectedItem ? "text-slate-900" : "text-slate-400")}>
          {selectedItem ? selectedItem.name : placeholder || "اختر المادة..."}
        </span>
        <ChevronDown size={16} className={cn("text-slate-400 transition-transform", isOpen && "rotate-180")} />
      </div>

      {isOpen && (
        <div className="absolute z-[110] w-full mt-2 bg-white border border-slate-200 rounded-[1.5rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
          <div className="p-3 bg-slate-50 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input 
                autoFocus
                className="w-full pr-9 pl-4 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="بحث بالاسم أو الباركود..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="max-h-60 overflow-y-auto">
            {filteredItems.map(item => (
              <div 
                key={item.id}
                onClick={() => { onChange(item.id); setIsOpen(false); setSearch(''); }}
                className="p-4 hover:bg-indigo-50 cursor-pointer border-b border-slate-50 last:border-0 transition-colors"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-black text-slate-800">{item.name}</span>
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">{item.category}</span>
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 font-bold uppercase">
                  <span>{item.barcode}</span>
                  <span className={cn(item.currentQty <= item.reorderLevel ? "text-rose-500" : "text-emerald-500")}>
                    الرصيد الحقيقي: {item.currentQty} {item.unit}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export const TransactionManager: React.FC<{
  type: 'inbound' | 'outbound',
  inventory: InventoryItem[],
  suppliers: Supplier[],
  onAddInbound: (log: InboundLog) => void,
  onAddOutbound: (log: OutboundLog) => void
}> = ({ type, inventory, suppliers, onAddInbound, onAddOutbound }) => {
  const { showToast, setActiveView } = useUIStore();
  const { categories, generateInventoryNo, systemSettings, updateSettings } = useInventoryStore();
  
  const [items, setItems] = useState([{ 
    id: Date.now(), 
    itemId: '', 
    quantity: 1, 
    unit: '', 
    conversionRate: 1,
    inventoryNo: ''
  }]);
  
  const [globalData, setGlobalData] = useState({
    date: new Date().toLocaleDateString('en-GB').split('/').join('/'), // Keep standard DD/MM/YYYY
    recipient: '',
    department: '',
    supplier: '',
    orderNo: '',
    invoiceNo: '',
    receiptNo: '',
    officeNumber: '',
    recipientEntity: '',
    recipientEmployeeId: '',
    notes: '',
    deliveryType: DeliveryType.TEMPORARY
  });

  const signaturePadRef = useRef<SignatureCanvas>(null);

  const generateForItem = (rowId: number) => {
    const row = items.find(i => i.id === rowId);
    if (!row || !row.itemId || !systemSettings) return;

    const item = inventory.find(inv => inv.id === row.itemId);
    const cat = categories.find(c => c.name === item?.category);
    
    // Count how many rows have an inventory number already to offset the sequence
    const assignedCount = items.filter(i => i.inventoryNo).length;
    
    const year = systemSettings.includeYear ? new Date().getFullYear().toString().slice(-2) : '';
    const parts = [systemSettings.globalPrefix];
    
    if (cat?.prefix) parts.push(cat.prefix);
    if (year) parts.push(year);
    
    parts.push((systemSettings.nextSequence + assignedCount).toString());
    
    const generated = parts.join('-');
    setItems(items.map(it => it.id === rowId ? { ...it, inventoryNo: generated } : it));
  };

  const handleAction = async () => {
    if (items.some(i => !i.itemId)) {
      showToast('يرجى اختيار جميع المواد أولاً', 'error');
      return;
    }

    if (type === 'inbound' && !globalData.supplier) {
      showToast('يرجى اختيار المورد أولاً', 'error');
      return;
    }

    let itemsProcessed = 0;
    let sequenceIncrement = 0;

    items.forEach(i => {
      const inventoryItem = inventory.find(inv => inv.id === i.itemId);
      if (!inventoryItem) return;

      // Check if user used auto-generated number (ends with current sequence)
      // Actually simpler: if they have ANY inventoryNo, we can track it.
      // But for now, let's just increment if they were in 'outbound' mode and provided numbers
      if (type === 'outbound' && i.inventoryNo) {
        sequenceIncrement++;
      }

      const baseLog = {
        id: `LOG-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        date: globalData.date,
        itemId: i.itemId,
        itemName: inventoryItem.name,
        quantity: i.quantity,
        unit: i.unit || inventoryItem.unit,
        conversionRate: i.conversionRate,
        notes: globalData.notes,
        officeNumber: globalData.officeNumber,
        department: globalData.department,
        inventoryNo: i.inventoryNo
      };

      if (type === 'inbound') {
        onAddInbound({
          ...baseLog,
          supplier: globalData.supplier,
          orderNo: globalData.orderNo,
          invoiceNo: globalData.invoiceNo,
          receiptNo: globalData.receiptNo
        } as InboundLog);
      } else {
        onAddOutbound({
          ...baseLog,
          recipientName: globalData.recipient,
          recipientEntity: globalData.recipientEntity,
          recipientEmployeeId: globalData.recipientEmployeeId,
          deliveryType: globalData.deliveryType,
          signature: signaturePadRef.current?.toDataURL() || ''
        } as OutboundLog);
      }
    });

    if (type === 'outbound' && sequenceIncrement > 0 && systemSettings) {
      await updateSettings({ nextSequence: systemSettings.nextSequence + sequenceIncrement });
    }

    showToast(type === 'inbound' ? 'تم تسجيل الوارد بنجاح' : 'تم تسجيل الصرف بنجاح', 'success');
    setItems([{ id: Date.now(), itemId: '', quantity: 1, unit: '', conversionRate: 1, inventoryNo: '' }]);
    setGlobalData({
      ...globalData,
      recipient: '',
      department: '',
      supplier: '',
      orderNo: '',
      invoiceNo: '',
      receiptNo: '',
      officeNumber: '',
      recipientEntity: '',
      recipientEmployeeId: '',
      notes: ''
    });
    signaturePadRef.current?.clear();
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <BrandingHeader 
        title={type === 'inbound' ? "سجل وارد جديد" : "سجل صرف جديد"} 
        subtitle={type === 'inbound' 
          ? "مصلحة الوسائل - مخزن الكلية" 
          : "مصلحة الوسائل والصيانة - كلية الحقوق"} 
      />

      {type === 'inbound' && (
        <div className="text-center -mt-4 mb-2">
          <p className="text-sm text-slate-500 font-bold">يرجى ملء البيانات بدقة لضمان صحة السجلات الإدارية</p>
        </div>
      )}

      <div className="bg-white rounded-[3rem] shadow-sm border border-slate-200/60 p-10 space-y-10">
        {/* Global Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">تاريخ العملية</label>
            <div className="relative">
              <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                className="w-full pr-12 pl-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none focus:border-indigo-400"
                value={globalData.date}
                onChange={e => setGlobalData({...globalData, date: e.target.value})}
              />
            </div>
          </div>

          {type === 'inbound' ? (
            <>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">المورد</label>
                <select 
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                  value={globalData.supplier}
                  onChange={e => setGlobalData({...globalData, supplier: e.target.value})}
                >
                  <option value="">اسم المورد أو المؤسسة</option>
                  {suppliers.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">رقم سند الطلب</label>
                <input 
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none shadow-sm"
                  placeholder="رقم سند الطلب (Bon de Commande)"
                  value={globalData.orderNo}
                  onChange={e => setGlobalData({...globalData, orderNo: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">رقم الفاتورة</label>
                <input 
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none shadow-sm"
                  placeholder="رقم الفاتورة (Facture)"
                  value={globalData.invoiceNo}
                  onChange={e => setGlobalData({...globalData, invoiceNo: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">رقم وصل الاستلام</label>
                <input 
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none shadow-sm"
                  placeholder="رقم وصل الاستلام (Bon de Réception)"
                  value={globalData.receiptNo}
                  onChange={e => setGlobalData({...globalData, receiptNo: e.target.value})}
                />
              </div>
            </>
          ) : (
            <>
              <div className="space-y-4 col-span-full">
                <h3 className="text-xs font-black text-indigo-500 uppercase tracking-[2px] border-b border-indigo-50 pb-2">تفاصيل المستلم والموقع</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">المؤسسة المستلمة</label>
                    <input 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                      placeholder="اسم المؤسسة (إذا وجد)"
                      value={globalData.recipientEntity}
                      onChange={e => setGlobalData({...globalData, recipientEntity: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">المصلحة / القسم</label>
                    <input 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                      placeholder="مثال: الأمانة العامة"
                      value={globalData.department}
                      onChange={e => setGlobalData({...globalData, department: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">رقم المكتب</label>
                    <input 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                      placeholder="رقم المكتب أو القاعة"
                      value={globalData.officeNumber}
                      onChange={e => setGlobalData({...globalData, officeNumber: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">اسم المستلم</label>
                    <input 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                      placeholder="الاسم واللقب الكامل"
                      value={globalData.recipient}
                      onChange={e => setGlobalData({...globalData, recipient: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">رقم الموظف</label>
                    <input 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                      placeholder="رقم بطاقة المهنة"
                      value={globalData.recipientEmployeeId}
                      onChange={e => setGlobalData({...globalData, recipientEmployeeId: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">طبيعة التسليم</label>
                    <select 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                      value={globalData.deliveryType}
                      onChange={e => setGlobalData({...globalData, deliveryType: e.target.value as DeliveryType})}
                    >
                      {Object.values(DeliveryType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Signature Pad for Outbound */}
        {type === 'outbound' && (
          <div className="space-y-4">
             <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">توقيع المستلم (رقمياً)</label>
             <div className="bg-slate-50 border border-slate-100 rounded-3xl p-4">
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden h-40">
                  <SignatureCanvas 
                    ref={signaturePadRef}
                    penColor="black"
                    canvasProps={{ className: "signature-canvas w-full h-full" }}
                  />
                </div>
                <div className="mt-3 flex justify-end">
                   <button 
                    onClick={() => signaturePadRef.current?.clear()}
                    className="text-[10px] py-1.5 px-4 bg-white border border-slate-200 rounded-xl font-black text-slate-400 hover:text-rose-500 hover:border-rose-100 transition-all"
                   >
                     مسح التوقيع
                   </button>
                </div>
             </div>
          </div>
        )}

        {/* Notes */}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">ملاحظات إضافية</label>
          <textarea 
            className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none min-h-[100px]"
            placeholder="أي تفاصيل أو شروط خاصة بالعملية..."
            value={globalData.notes}
            onChange={e => setGlobalData({...globalData, notes: e.target.value})}
          />
        </div>

        {/* Attachments Section (Mocked UI) */}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">المرفقات والمستندات (خارج التطبيق)</label>
          <div className="p-6 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50 text-center">
            <p className="text-xs text-slate-400 font-bold mb-3">تحميل مستندات (صور، PDF، فواتير...)</p>
            <input type="file" className="text-xs text-slate-400" />
          </div>
        </div>

        {/* Items List */}
        <div className="space-y-6 pt-6 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-[2px]">قائمة المواد والأصناف</h3>
            <div className="flex gap-2">
               <button 
                onClick={() => setItems([...items, { id: Date.now(), itemId: '', quantity: 1, unit: '', conversionRate: 1, inventoryNo: '' }])}
                className="text-[10px] bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl font-black hover:bg-indigo-100 transition-colors"
              >
                + إضافة سطر جديد
              </button>
              <button 
                onClick={() => setItems([{ id: Date.now(), itemId: '', quantity: 1, unit: '', conversionRate: 1, inventoryNo: '' }])}
                className="text-[10px] bg-slate-50 text-slate-500 px-4 py-2 rounded-xl font-black hover:bg-slate-100 transition-colors"
              >
                مسح
              </button>
            </div>
          </div>

          <div className="space-y-6">
            {items.map((row, index) => {
              const selectedInventoryItem = inventory.find(i => i.id === row.itemId);
              return (
                <div key={row.id} className="bg-slate-50/50 p-6 rounded-[2rem] border border-slate-100 space-y-4 relative animate-in slide-in-from-right-4 duration-300">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-black text-slate-400 uppercase">المادة / الصنف ({index + 1})</span>
                    {items.length > 1 && (
                      <button 
                        onClick={() => setItems(items.filter(i => i.id !== row.id))}
                        className="text-rose-400 hover:text-rose-600 transition-colors p-1"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                    <div className="lg:col-span-1 space-y-2">
                      <div className="flex gap-1 mb-1">
                        <button 
                          onClick={() => setActiveView('categories')}
                          className="text-[9px] bg-white border border-slate-200 text-slate-400 px-2 py-0.5 rounded-lg hover:text-indigo-600 hover:border-indigo-200 transition-all font-bold"
                        >
                          + فئة جديدة
                        </button>
                        <button 
                          onClick={() => setActiveView('inventory')}
                          className="text-[9px] bg-white border border-slate-200 text-slate-400 px-2 py-0.5 rounded-lg hover:text-indigo-600 hover:border-indigo-200 transition-all font-bold"
                        >
                          + مادة جديدة
                        </button>
                      </div>
                      <SearchableItemSelector 
                        items={inventory}
                        value={row.itemId}
                        onChange={val => {
                          const item = inventory.find(inv => inv.id === val);
                          setItems(items.map(i => i.id === row.id ? {
                            ...i, 
                            itemId: val, 
                            unit: item?.unit || '' 
                          } : i));
                        }}
                        placeholder="ابحث عن مادة..."
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase px-1">الكمية</label>
                      <input 
                        type="number"
                        min="1"
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-black text-center outline-none focus:ring-2 focus:ring-indigo-500"
                        value={row.quantity}
                        onChange={e => setItems(items.map(i => i.id === row.id ? {...i, quantity: Number(e.target.value)} : i))}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase px-1">الوحدة</label>
                      <select 
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500"
                        value={row.unit}
                        onChange={e => setItems(items.map(i => i.id === row.id ? {...i, unit: e.target.value} : i))}
                      >
                        <option value="">الوحدة...</option>
                        {Object.values(Unit).map(u => <option key={u} value={u}>{u}</option>)}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase px-1">معدل التحويل</label>
                      <input 
                        type="number"
                        min="1"
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-black text-center outline-none focus:ring-2 focus:ring-indigo-500"
                        value={row.conversionRate}
                        onChange={e => setItems(items.map(i => i.id === row.id ? {...i, conversionRate: Number(e.target.value)} : i))}
                      />
                    </div>

                    {type === 'outbound' && (
                      <div className="space-y-2 lg:col-span-4">
                        <div className="flex justify-between items-center px-1">
                          <label className="text-[9px] font-black text-slate-400 uppercase">رقم الجرد</label>
                          <button 
                            onClick={() => generateForItem(row.id)}
                            className="text-[9px] text-indigo-600 font-bold hover:underline"
                          >
                            توليد رقم تلقائي
                          </button>
                        </div>
                        <input 
                          className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                          placeholder="مثال: UNIV-GHA-LAW-26-1001"
                          value={row.inventoryNo}
                          onChange={e => setItems(items.map(i => i.id === row.id ? {...i, inventoryNo: e.target.value} : i))}
                        />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="pt-10 border-t border-slate-100 flex flex-col md:flex-row gap-6">
           <button 
             onClick={handleAction}
             className={cn(
               "flex-[2] py-5 rounded-[2rem] text-white font-black text-lg shadow-2xl transition-all flex items-center justify-center gap-3",
               type === 'inbound' ? "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100" : "bg-slate-900 hover:bg-black shadow-slate-200"
             )}
           >
             <Send size={20} />
             {type === 'inbound' ? "تأكيد واستلام المواد" : "تأكيد وتسجيل العملية"}
           </button>
           <button className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-[2rem] font-bold hover:bg-slate-200 transition-all flex items-center justify-center gap-2">
             <Printer size={18} />
             معاينة الوصل
           </button>
        </div>
      </div>
      
      <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-[2rem] flex gap-4 items-start">
        <AlertCircle className="text-indigo-500 flex-shrink-0" size={20} />
        <div>
          <p className="text-[10px] font-black text-indigo-700 uppercase tracking-widest mb-1">تعليمات إدارية</p>
          <p className="text-xs text-indigo-600 leading-relaxed font-bold">
            * جميع العمليات يتم أرشفتها تلقائياً في سجل الحركة اليومي.
          </p>
        </div>
      </div>
    </div>
  );
};
