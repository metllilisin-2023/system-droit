import React, { useState, useEffect } from 'react';
import { X, PlusCircle, Edit, Sparkles, AlertCircle } from 'lucide-react';
import { InventoryItem, Category, Unit } from '../../types';

interface AddItemModalProps {
  categories: Category[];
  inventory: InventoryItem[];
  onClose: () => void;
  onSave: (item: InventoryItem) => void;
}

export const AddItemModal: React.FC<AddItemModalProps> = ({ categories, inventory, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<InventoryItem>>({
    id: '', barcode: '', name: '', description: '',
    category: categories[0]?.name || '', unit: Unit.PIECE,
    subUnit: '', piecesPerUnit: 1, initialStock: 0,
    inbound: 0, outbound: 0, currentQty: 0, reorderLevel: 5, price: 0
  });

  useEffect(() => {
    if (formData.name && formData.category) {
      const category = categories.find(c => c.name === formData.category);
      const prefix = category?.prefix || 'ITEM';
      const categoryItems = inventory.filter(item => item.category === formData.category);
      const sequence = (categoryItems.length + 1).toString().padStart(3, '0');
      setFormData(prev => ({ ...prev, id: `${prefix}-${sequence}` }));
    }
  }, [formData.name, formData.category, categories, inventory]);

  const generateBarcode = () => {
    const year = new Date().getFullYear().toString().slice(-2);
    const barcodes = inventory
      .map(i => i.barcode)
      .filter(b => b && b.startsWith(`ج غ /${year}/`))
      .map(b => parseInt(b.split('/').pop() || '0'))
      .filter(n => !isNaN(n));
    const nextSerial = barcodes.length > 0 ? Math.max(...barcodes) + 1 : 1001;
    setFormData(prev => ({ ...prev, barcode: `ج غ /${year}/${nextSerial.toString().padStart(4, '0')}` }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, currentQty: formData.initialStock || 0 } as InventoryItem);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden shadow-indigo-100/50">
        <div className="p-8 bg-slate-900 text-white flex justify-between items-center bg-gradient-to-r from-slate-900 to-indigo-950">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md">
              <PlusCircle className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-xl font-black tracking-tight">إضافة مادة جديدة</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">مخازن كلية الحقوق</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
            <X size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-10 space-y-8 max-h-[75vh] overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">تسمية المادة</label>
              <input 
                required
                className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-indigo-50 outline-none focus:border-indigo-400 transition-all font-bold"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                placeholder="مثال: طابعة ليزر HP"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">المعرف التسلسلي</label>
              <input 
                readOnly
                className="w-full px-5 py-4 bg-indigo-50/50 border border-indigo-100 rounded-2xl text-sm font-mono font-bold text-indigo-600 cursor-not-allowed"
                value={formData.id}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">الفئة التقنية</label>
              <select 
                className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-indigo-50 outline-none"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                {categories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">رمز الباركود</label>
              <div className="flex gap-2">
                <input 
                  className="flex-1 px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-mono focus:ring-4 focus:ring-indigo-50 outline-none"
                  value={formData.barcode}
                  onChange={e => setFormData({...formData, barcode: e.target.value})}
                />
                <button type="button" onClick={generateBarcode} className="p-4 bg-indigo-600 text-white rounded-2xl hover:bg-black transition-all shadow-lg shadow-indigo-100">
                  <Sparkles size={18} />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">وحدة القياس</label>
              <select 
                className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-indigo-50 outline-none"
                value={formData.unit}
                onChange={e => setFormData({...formData, unit: e.target.value as Unit})}
              >
                {Object.values(Unit).map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">الرصيد الابتدائي</label>
              <input 
                type="number"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-indigo-50 outline-none"
                value={formData.initialStock}
                onChange={e => setFormData({...formData, initialStock: Number(e.target.value)})}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">حد الإنذار (الحد الأدنى)</label>
              <input 
                type="number"
                className="w-full px-5 py-4 bg-rose-50/30 border border-rose-100 rounded-2xl text-sm focus:ring-4 focus:ring-rose-50 outline-none text-rose-600 font-bold"
                value={formData.reorderLevel}
                onChange={e => setFormData({...formData, reorderLevel: Number(e.target.value)})}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">سعر الوحدة (دج)</label>
              <input 
                type="number"
                className="w-full px-5 py-4 bg-emerald-50/30 border border-emerald-100 rounded-2xl text-sm font-mono text-emerald-700 font-bold outline-none"
                value={formData.price}
                onChange={e => setFormData({...formData, price: Number(e.target.value)})}
              />
            </div>
          </div>

          <div className="pt-8 flex gap-4">
             <button type="submit" className="flex-[2] py-5 bg-slate-900 text-white rounded-[1.5rem] font-black shadow-xl shadow-slate-200 hover:bg-black transition-all">تأكيد الإضافة</button>
             <button type="button" onClick={onClose} className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-[1.5rem] font-bold hover:bg-slate-200 transition-all">إلغاء</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const EditItemModal: React.FC<{
  item: InventoryItem;
  categories: Category[];
  onClose: () => void;
  onSave: (item: InventoryItem) => void;
}> = ({ item, categories, onClose, onSave }) => {
  const [formData, setFormData] = useState<InventoryItem>({ ...item });

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-xl overflow-hidden shadow-indigo-100/50 border border-white">
        <div className="p-8 bg-slate-900 text-white flex justify-between items-center bg-gradient-to-r from-slate-900 to-slate-800">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 rounded-2xl">
              <Edit className="w-6 h-6 text-indigo-400" />
            </div>
            <h3 className="text-xl font-black">تعديل بيانات الصنف</h3>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors"><X size={24} /></button>
        </div>
        
        <form onSubmit={e => {e.preventDefault(); onSave(formData)}} className="p-10 space-y-6">
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">اسم المادة</label>
            <input 
              required
              className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold shadow-inner"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">الرصيد الحالي (معدل)</label>
              <div className="relative">
                <input 
                  type="number"
                  className="w-full px-5 py-4 bg-amber-50/50 border border-amber-100 rounded-2xl text-sm font-black text-amber-700"
                  value={formData.currentQty}
                  onChange={e => setFormData({...formData, currentQty: Number(e.target.value)})}
                />
                <AlertCircle className="absolute left-4 top-1/2 -translate-y-1/2 text-amber-400 w-4 h-4" />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">سعر الوحدة</label>
              <input 
                type="number"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold"
                value={formData.price}
                onChange={e => setFormData({...formData, price: Number(e.target.value)})}
              />
            </div>
          </div>

          <div className="pt-6 flex gap-3">
             <button type="submit" className="flex-[2] py-5 bg-indigo-600 text-white rounded-[1.2rem] font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">حفظ التغييرات</button>
             <button type="button" onClick={onClose} className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-[1.2rem] font-bold">إلغاء</button>
          </div>
        </form>
      </div>
    </div>
  );
};
