import React, { useRef, useEffect } from 'react';
import { X, Printer, Barcode } from 'lucide-react';
import JsBarcode from 'jsbarcode';
import { InventoryItem } from '../../types';

interface BarcodeModalProps {
  item: InventoryItem;
  onClose: () => void;
}

const BarcodeModal: React.FC<BarcodeModalProps> = ({ item, onClose }) => {
  const barcodeRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (barcodeRef.current && item.barcode) {
      try {
        JsBarcode(barcodeRef.current, item.barcode, {
          format: "CODE128",
          lineColor: "#000",
          width: 2,
          height: 100,
          displayValue: true,
          fontOptions: "bold",
          fontSize: 16,
          font: "monospace",
          textMargin: 6,
          margin: 10
        });
      } catch (err) {
        console.error("Barcode Generation Error:", err);
      }
    }
  }, [item]);

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const html = `
      <html dir="rtl">
        <head>
          <title>ملصق باركود - ${item.name}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@700&display=swap');
            body { 
              display: flex; 
              flex-direction: column; 
              align-items: center; 
              justify-content: center; 
              height: 100vh; 
              margin: 0;
              font-family: 'Tajawal', sans-serif;
            }
            .label-card {
              border: 2px solid #000;
              padding: 40px;
              text-align: center;
              border-radius: 10px;
            }
            .item-name {
              font-size: 24px;
              font-weight: bold;
              margin-bottom: 20px;
            }
            .barcode-svg {
              max-width: 100%;
            }
          </style>
        </head>
        <body>
          <div class="label-card">
            <div class="item-name">${item.name}</div>
            <div id="barcode-container"></div>
            <div style="margin-top: 10px; font-size: 14px;">جامعة غرداية - كلية الحقوق</div>
          </div>
          <script>
            const svg = '${barcodeRef.current?.outerHTML || ''}';
            document.getElementById('barcode-container').innerHTML = svg;
            window.onload = () => {
              window.print();
              window.close();
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-white">
        <div className="p-8 bg-slate-900 text-white flex justify-between items-center bg-gradient-to-br from-slate-900 to-indigo-950">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 rounded-2xl">
              <Barcode className="w-6 h-6 text-indigo-400" />
            </div>
            <h3 className="text-xl font-black">توليد ملصق الباركود</h3>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-10 flex flex-col items-center space-y-8">
          <div className="text-center space-y-1">
            <p className="text-2xl font-black text-slate-800 tracking-tight">{item.name}</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.category}</p>
          </div>
          
          <div className="p-10 bg-slate-50 border border-slate-100 rounded-[2rem] shadow-inner flex justify-center w-full overflow-hidden">
            <svg ref={barcodeRef} className="max-w-full"></svg>
          </div>

          <div className="flex gap-4 w-full">
            <button 
              onClick={handlePrint}
              className="flex-[2] py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3"
            >
              <Printer size={20} />
              طباعة الملصق
            </button>
            <button 
              onClick={onClose}
              className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-2xl font-bold hover:bg-slate-200 transition-all"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BarcodeModal;
