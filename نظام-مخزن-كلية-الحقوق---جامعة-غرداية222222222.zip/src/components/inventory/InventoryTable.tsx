import React, { useState } from 'react';
import { 
  Package, 
  Printer, 
  FileSpreadsheet, 
  PlusCircle, 
  Search, 
  Edit, 
  Barcode, 
  MinusCircle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { InventoryItem, Category, UserRole } from '../../types';
import { cn } from '../../lib/utils';
import { BrandingHeader } from '../ui/BrandingHeader';

interface InventoryTableProps {
  inventory: InventoryItem[];
  role: UserRole;
  categories: Category[];
  isAdmin: boolean;
  onAddItem: () => void;
  onEditItem: (item: InventoryItem) => void;
  onDeleteItem: (id: string) => void;
  onShowBarcode: (item: InventoryItem) => void;
}

const UNIVERSITY_LOGO_URL = "https://raw.githubusercontent.com/Anis-Mtl/stock-manager/main/public/univ_logo.png";
const FACULTY_LOGO_URL = "https://raw.githubusercontent.com/Anis-Mtl/stock-manager/main/public/faculty_logo.png";

const formatQuantity = (qty: number, unit: string, subUnit?: string, piecesPerUnit?: number) => {
  if (!subUnit || !piecesPerUnit || piecesPerUnit <= 1) return `${qty} ${unit}`;
  const mainUnits = Math.floor(qty);
  const remainingPieces = Math.round((qty - mainUnits) * piecesPerUnit);
  if (mainUnits === 0) return `${remainingPieces} ${subUnit}`;
  if (remainingPieces === 0) return `${mainUnits} ${unit}`;
  return `${mainUnits} ${unit} و ${remainingPieces} ${subUnit}`;
};

export const InventoryTable: React.FC<InventoryTableProps> = ({ 
  inventory, 
  categories, 
  isAdmin, 
  onAddItem, 
  onEditItem, 
  onDeleteItem,
  onShowBarcode 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filtered = inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.barcode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  }).sort((a, b) => {
    // الترتيب حسب الفئة أولاً
    const catCompare = a.category.localeCompare(b.category, 'ar');
    if (catCompare !== 0) return catCompare;
    // ثم الترتيب حسب الاسم أبجدياً داخل الفئة
    return a.name.localeCompare(b.name, 'ar');
  });

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html dir="rtl">
        <head>
          <title>تقرير وضعية المخزون</title>
          <style>
             @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap');
             body { font-family: 'Tajawal', sans-serif; padding: 40px; }
             table { width: 100%; border-collapse: collapse; margin-top: 30px; }
             th, td { border: 1px solid #000; padding: 12px; text-align: right; font-size: 12px; }
             th { background: #f1f5f9; }
             .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #000; padding-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
             <img src="${UNIVERSITY_LOGO_URL}" style="height: 60px;" />
             <div style="text-align: center;">
               <h2>جامعة غرداية</h2>
               <h3>كلية الحقوق والعلوم السياسية</h3>
             </div>
             <img src="${FACULTY_LOGO_URL}" style="height: 60px;" />
          </div>
          <h1 style="text-align: center;">تقرير جرد المخزون الحالي</h1>
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>الباركود</th>
                <th>اسم المادة</th>
                <th>الفئة</th>
                <th>الرصيد</th>
                <th>الوحدة</th>
              </tr>
            </thead>
            <tbody>
              ${filtered.map((item, idx) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td>${item.barcode}</td>
                  <td>${item.name}</td>
                  <td>${item.category}</td>
                  <td>${formatQuantity(item.currentQty, item.unit, item.subUnit, item.piecesPerUnit)}</td>
                  <td>${item.unit}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <script>window.print(); window.close();</script>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const handleExcelExport = () => {
    const worksheet = XLSX.utils.json_to_sheet(filtered);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory");
    XLSX.writeFile(workbook, `مخزون_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <BrandingHeader title="المخزن العام" subtitle="جرد المواد واللوازم الحالية" />
      
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-3">
            <div className="p-2 bg-indigo-600 text-white rounded-xl">
              <Package size={20} />
            </div>
            المخزون الفعلي
          </h2>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex bg-white p-1 rounded-xl shadow-sm border border-slate-200 gap-1 overflow-x-auto max-w-full">
            <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 rounded-lg text-xs font-bold text-slate-600 transition-all border border-transparent hover:border-slate-100">
              <Printer size={14} /> طباعة PDF
            </button>
            <div className="w-[1px] bg-slate-200 my-1 mx-1"></div>
            <button onClick={handleExcelExport} className="flex items-center gap-2 px-4 py-2 hover:bg-emerald-50 rounded-lg text-xs font-bold text-emerald-600 transition-all border border-transparent hover:border-emerald-100">
              <FileSpreadsheet size={14} /> تصدير Excel
            </button>
          </div>
          
          {isAdmin && (
            <button onClick={onAddItem} className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-black transition-all shadow-lg shadow-slate-200">
              <PlusCircle size={16} /> إضافة صنف
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="relative group">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
          <input 
            type="text" 
            placeholder="البحث بالاسم، المعرف أو الباركود..." 
            className="w-full pr-12 pl-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm focus:ring-4 focus:ring-indigo-50 outline-none focus:border-indigo-400 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="relative">
          <select 
            className="w-full px-5 py-3 bg-white border border-slate-200 rounded-2xl text-sm focus:ring-4 focus:ring-indigo-50 outline-none focus:border-indigo-400 transition-all appearance-none"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="all">جميع الفئات</option>
            {categories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
          </select>
          <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
            <Package size={14} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-200/60 overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-200">
          <table className="w-full text-right">
            <thead className="bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">المعرف</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">الباركود</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">اسم المادة</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">الفئة</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">الرصيد</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">الوحدة</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">الحالة</th>
                {isAdmin && <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[2px]">الإجراءات</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(item => (
                <tr key={item.id} className="hover:bg-indigo-50/20 transition-colors group">
                  <td className="px-8 py-5 text-xs font-mono text-slate-400">#{item.id}</td>
                  <td className="px-8 py-5 text-xs font-mono text-indigo-500 font-bold">{item.barcode}</td>
                  <td className="px-8 py-5">
                    <div className="font-black text-slate-800 text-sm">{item.name}</div>
                  </td>
                  <td className="px-8 py-5">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-[10px] font-bold">{item.category}</span>
                  </td>
                  <td className="px-8 py-5 font-black text-slate-900 text-sm">
                    {formatQuantity(item.currentQty, item.unit, item.subUnit, item.piecesPerUnit)}
                  </td>
                  <td className="px-8 py-5 text-xs text-slate-500 font-bold">{item.unit}</td>
                  <td className="px-8 py-5">
                    <div className={cn(
                      "inline-flex items-center px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider",
                      item.currentQty <= item.reorderLevel 
                        ? "bg-rose-50 text-rose-600 border border-rose-100" 
                        : "bg-emerald-50 text-emerald-600 border border-emerald-100"
                    )}>
                      {item.currentQty <= item.reorderLevel ? "منخفض" : "متوفر"}
                    </div>
                  </td>
                  {isAdmin && (
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => onEditItem(item)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-xl shadow-sm transition-all border border-transparent hover:border-indigo-100">
                          <Edit size={14} />
                        </button>
                        <button onClick={() => onShowBarcode(item)} className="p-2 text-slate-400 hover:text-slate-900 hover:bg-white rounded-xl shadow-sm transition-all border border-transparent hover:border-slate-200">
                          <Barcode size={14} />
                        </button>
                        <button onClick={() => onDeleteItem(item.id)} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-white rounded-xl shadow-sm transition-all border border-transparent hover:border-rose-100">
                          <MinusCircle size={14} />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
             <div className="py-20 text-center text-slate-400 space-y-4">
               <Package className="w-12 h-12 mx-auto opacity-10" />
               <p className="text-sm font-bold">لا توجد مواد تطابق معايير البحث.</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};


