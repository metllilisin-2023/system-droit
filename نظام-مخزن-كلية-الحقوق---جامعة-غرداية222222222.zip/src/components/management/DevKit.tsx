import React from 'react';
import { Database, Trash2, Download, Upload, ShieldAlert, Code2, RefreshCcw, HardDrive } from 'lucide-react';
import { useInventoryStore } from '../../store/inventoryStore';
import { useUIStore } from '../../store/uiStore';
import { BrandingHeader } from '../ui/BrandingHeader';

export const DevKit: React.FC = () => {
  const { clearAllData, exportDataToDisk, fetchData } = useInventoryStore();
  const { showToast, openConfirm } = useUIStore();

  const handleReset = () => {
    openConfirm(
      'تصفير النظام بالكامل',
      'تحذير صارم: هذا الإجراء سيقوم بحذف جميع المواد، السجلات، الفئات والموردين من قاعدة البيانات نهائياً. هل أنت متأكد من المتابعة؟',
      async () => {
        try {
          await clearAllData();
          showToast('تم تصفير قاعدة البيانات بنجاح', 'success');
        } catch (err: any) {
          showToast(`خطأ أثناء التصفير: ${err.message}`, 'error');
        }
      }
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 animate-in fade-in duration-700 p-8">
      <BrandingHeader title="أدوات المطور والمشرف" subtitle="تحكم في تهيئة النظام وصيانة قاعدة البيانات" />
      
      <header className="text-center space-y-3">
        <div className="w-20 h-20 bg-slate-100 rounded-[2.5rem] flex items-center justify-center mx-auto mb-6">
          <Code2 size={36} className="text-slate-400" />
        </div>
        <h2 className="text-3xl font-black text-slate-800 tracking-tight">أدوات المطور والمشرف</h2>
        <p className="text-sm text-slate-400 font-bold uppercase tracking-widest max-w-lg mx-auto">
          تحكم في تهيئة النظام، عمليات النسخ الاحتياطي، وصيانة قاعدة البيانات السحابية
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Backup & Restore */}
        <section className="bg-white rounded-[3rem] p-10 border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
              <HardDrive size={24} />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-800">البيانات المحلية</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase">التحكم في القرص الصلب</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <button 
              onClick={() => exportDataToDisk()}
              className="w-full flex items-center justify-between p-6 bg-slate-50 border border-slate-100 rounded-3xl hover:border-indigo-400 transition-all group"
            >
              <div className="text-right">
                <p className="text-sm font-black text-slate-700">تصدير نسخة احتياطية</p>
                <p className="text-[10px] text-slate-400 font-bold">حفظ ملف JSON إلى الحاسوب</p>
              </div>
              <Download className="text-slate-300 group-hover:text-indigo-600 transition-colors" />
            </button>

            <button className="w-full flex items-center justify-between p-6 bg-slate-50 border border-slate-100 rounded-3xl hover:border-emerald-400 transition-all group">
              <div className="text-right">
                <p className="text-sm font-black text-slate-700">استيراد بيانات</p>
                <p className="text-[10px] text-slate-400 font-bold">رفع ملف تهيئة سابق</p>
              </div>
              <Upload className="text-slate-300 group-hover:text-emerald-600 transition-colors" />
            </button>
          </div>
        </section>

        {/* System Operations */}
        <section className="bg-white rounded-[3rem] p-10 border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-rose-50 text-rose-600 rounded-2xl">
              <ShieldAlert size={24} />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-800">عمليات خطيرة</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase">تنبيه: لا يمكن التراجع</p>
            </div>
          </div>

          <div className="space-y-4">
            <button 
              onClick={handleReset}
              className="w-full flex items-center justify-between p-6 bg-rose-50/50 border border-rose-100 rounded-3xl hover:bg-rose-100 transition-all group"
            >
              <div className="text-right">
                <p className="text-sm font-black text-rose-700">تصفير النظام (Clear All)</p>
                <p className="text-[10px] text-rose-400 font-bold italic">حذف فوري لكامل قاعدة البيانات</p>
              </div>
              <Trash2 className="text-rose-300 group-hover:text-rose-600 transition-colors" />
            </button>

            <button 
              onClick={() => fetchData()}
              className="w-full flex items-center justify-between p-6 bg-slate-50 border border-slate-100 rounded-3xl hover:border-slate-400 transition-all group"
            >
              <div className="text-right">
                <p className="text-sm font-black text-slate-700">مزامنة قسرية</p>
                <p className="text-[10px] text-slate-400 font-bold">إعادة جلب جميع البيانات من الخادم</p>
              </div>
              <RefreshCcw className="text-slate-300 group-hover:text-slate-600 transition-colors" />
            </button>
          </div>
        </section>
      </div>

      <div className="p-8 bg-slate-50 rounded-[3rem] border border-slate-100">
        <div className="flex gap-4">
           <Database className="text-slate-400 shrink-0" size={20} />
           <p className="text-[10px] leading-relaxed text-slate-500 font-bold uppercase tracking-wider">
             هذه الواجهة مخصصة للمسؤولين التقنيين فقط. الاستخدام غير الصحيح قد يؤدي لضياع البيانات أو اختلال في الترقيم التسلسلي للمقتنيات. جميع العمليات في هذه الصفحة يتم تسجيلها في "سجل التدقيق الأمني" (Audit Trail).
           </p>
        </div>
      </div>
    </div>
  );
};
