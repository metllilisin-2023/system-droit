import React, { useState } from 'react';
import { Tags, Users, PlusCircle, Trash2, Edit, X, Save, Database } from 'lucide-react';
import { Category, Supplier } from '../../types';
import { useInventoryStore } from '../../store/inventoryStore';
import { BrandingHeader } from '../ui/BrandingHeader';

export const CategoryManager: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory } = useInventoryStore();
  const [newCat, setNewCat] = useState({ name: '', prefix: '' });
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleAdd = async () => {
    if (!newCat.name) return;
    await addCategory({
      id: `CAT-${Date.now()}`,
      name: newCat.name,
      prefix: newCat.prefix || newCat.name.substring(0, 3).toUpperCase()
    });
    setNewCat({ name: '', prefix: '' });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <BrandingHeader title="إدارة التصنيفات" subtitle="تحكم في هيكلة المخزن والبادئات التسلسلية" />
      
      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200/60 p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end bg-slate-50 p-6 rounded-3xl border border-slate-100">
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">اسم الفئة</label>
            <input 
              className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-50 outline-none"
              placeholder="مثال: لوازم مكتبية"
              value={newCat.name}
              onChange={e => setNewCat({...newCat, name: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">البادئة (Prefix)</label>
            <input 
              className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-mono font-bold uppercase focus:ring-4 focus:ring-indigo-50 outline-none"
              placeholder="مثال: OFF (اختياري)"
              value={newCat.prefix}
              onChange={e => setNewCat({...newCat, prefix: e.target.value.toUpperCase()})}
            />
          </div>
          <button 
            onClick={handleAdd}
            className="py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm hover:bg-black transition-all shadow-lg shadow-indigo-100"
          >
            إضافة فئة جديدة
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map(cat => (
            <div key={cat.id} className="group relative bg-white border border-slate-200 rounded-3xl p-6 hover:border-indigo-400 transition-all hover:shadow-xl hover:shadow-indigo-50/50">
               <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 font-black text-xs">
                    {cat.prefix}
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => {
                        const newPrefix = prompt('أدخل البادئة الجديدة لهذه الفئة:', cat.prefix);
                        if (newPrefix !== null && newPrefix !== cat.prefix) {
                          updateCategory({ ...cat, prefix: newPrefix.toUpperCase() });
                        }
                      }}
                      className="p-2 text-indigo-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                    >
                      <Edit size={16} />
                    </button>
                    <button onClick={() => deleteCategory(cat.id)} className="p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all">
                      <Trash2 size={16} />
                    </button>
                  </div>
               </div>
               <h4 className="font-black text-slate-800 text-lg mb-1">{cat.name}</h4>
               <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">معرف الفئة: {cat.id}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const SupplierManager: React.FC = () => {
  const { suppliers, addSupplier, deleteSupplier } = useInventoryStore();
  const [newSup, setNewSup] = useState({ name: '', phone: '', email: '' });

  const handleAdd = async () => {
    if (!newSup.name) return;
    await addSupplier({
      id: `SUP-${Date.now()}`,
      ...newSup
    });
    setNewSup({ name: '', phone: '', email: '' });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <BrandingHeader title="قائمة الموردين" subtitle="إدارة الجهات والمصادر الخارجية" />

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200/60 p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end bg-slate-50 p-6 rounded-3xl border border-slate-100">
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">اسم المورد</label>
            <input 
              className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold outline-none"
              placeholder="اسم الشركة/المورد"
              value={newSup.name}
              onChange={e => setNewSup({...newSup, name: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">الهاتف</label>
            <input 
              className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold outline-none"
              placeholder="رقم الاتصال"
              value={newSup.phone}
              onChange={e => setNewSup({...newSup, phone: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">البريد الإلكتروني</label>
            <input 
              className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold outline-none"
              placeholder="البريد الإلكتروني"
              value={newSup.email}
              onChange={e => setNewSup({...newSup, email: e.target.value})}
            />
          </div>
          <button 
            onClick={handleAdd}
            className="py-4 bg-emerald-600 text-white rounded-2xl font-black text-sm hover:bg-black transition-all shadow-lg shadow-emerald-100"
          >
            إضافة مورد
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {suppliers.map(sup => (
            <div key={sup.id} className="bg-white border border-slate-200 rounded-3xl p-6 hover:shadow-xl transition-all group">
              <div className="flex justify-between items-start mb-4">
                 <div className="p-3 bg-slate-50 text-slate-400 rounded-2xl group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors">
                   <Users size={20} />
                 </div>
                 <button onClick={() => deleteSupplier(sup.id)} className="text-slate-200 hover:text-rose-500 transition-colors">
                    <Trash2 size={18} />
                 </button>
              </div>
              <h4 className="font-black text-slate-800 text-lg mb-2">{sup.name}</h4>
              <div className="space-y-1">
                <p className="text-xs text-slate-500 font-bold">{sup.phone || 'بدون هاتف'}</p>
                <p className="text-xs text-slate-400 font-medium">{sup.email || 'بدون بريد إلكتروني'}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
