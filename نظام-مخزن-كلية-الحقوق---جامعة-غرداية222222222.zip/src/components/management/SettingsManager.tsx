import React, { useState, useEffect } from 'react';
import { Settings, Save, Hash, Calendar, ShieldCheck } from 'lucide-react';
import { useInventoryStore } from '../../store/inventoryStore';
import { useUIStore } from '../../store/uiStore';
import { BrandingHeader } from '../ui/BrandingHeader';

export const SettingsManager: React.FC = () => {
  const { systemSettings, updateSettings, generateInventoryNo } = useInventoryStore();
  const { showToast } = useUIStore();
  const [formData, setFormData] = useState({
    globalPrefix: 'UNIV-GHA-LAW',
    includeYear: true,
    nextSequence: 1001
  });

  useEffect(() => {
    if (systemSettings) {
      setFormData({
        globalPrefix: systemSettings.globalPrefix,
        includeYear: systemSettings.includeYear,
        nextSequence: systemSettings.nextSequence
      });
    }
  }, [systemSettings]);

  const handleSave = async () => {
    try {
      await updateSettings(formData);
      showToast('تم حفظ إعدادات النظام بنجاح', 'success');
    } catch (error) {
      showToast('فشل في حفظ الإعدادات', 'error');
    }
  };

  const previewNo = generateInventoryNo('CAT');

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in duration-700">
      <BrandingHeader title="إعدادات النظام" subtitle="تكوين البادئة العامة وترقيم الجرد" />

      <div className="bg-white rounded-[3rem] p-10 border border-slate-200 shadow-sm space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="space-y-6">
            <h3 className="text-xl font-black text-slate-800 flex items-center gap-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <Settings size={20} />
              </div>
              تكوين البادئة (Prefix)
            </h3>
            
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">البادئة الرئيسية</label>
                <input 
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black focus:bg-white focus:ring-4 focus:ring-indigo-50 outline-none transition-all uppercase"
                  placeholder="مثال: UNIV-GHA-LAW"
                  value={formData.globalPrefix}
                  onChange={e => setFormData({ ...formData, globalPrefix: e.target.value.toUpperCase() })}
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white rounded-lg border border-slate-200">
                    <Calendar size={16} className="text-slate-400" />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-700 leading-none">تضمين السنة</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">إضافة 26 في رقم الجرد</p>
                  </div>
                </div>
                <button 
                  onClick={() => setFormData({ ...formData, includeYear: !formData.includeYear })}
                  className={`w-12 h-6 rounded-full transition-colors relative ${formData.includeYear ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${formData.includeYear ? 'left-7' : 'left-1'}`} />
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">التسلسل التالي</label>
                <div className="relative">
                  <input 
                    type="number"
                    className="w-full pl-5 pr-12 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black focus:bg-white focus:ring-4 focus:ring-indigo-50 outline-none transition-all"
                    value={formData.nextSequence}
                    onChange={e => setFormData({ ...formData, nextSequence: parseInt(e.target.value) || 0 })}
                  />
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-xl font-black text-slate-800 flex items-center gap-3">
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                <ShieldCheck size={20} />
              </div>
              معاينة الترقيم
            </h3>
            
            <div className="p-10 bg-slate-50 border-2 border-dashed border-slate-200 rounded-[2.5rem] flex flex-col items-center justify-center text-center space-y-4">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">مثال لرقم الجرد القادم</p>
              <div className="px-6 py-3 bg-white border border-slate-200 rounded-2xl shadow-sm">
                <code className="text-lg md:text-xl font-black text-indigo-600 tracking-wider">
                  {previewNo}
                </code>
              </div>
              <p className="text-[10px] text-slate-400 max-w-[200px] leading-relaxed">
                يتم استبدال 'CAT' تلقائياً ببادئة الفئة المختارة عند تسجيل مادة جديدة.
              </p>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 flex justify-end">
          <button 
            onClick={handleSave}
            className="flex items-center gap-3 px-10 py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-black transition-all shadow-xl shadow-indigo-100 group"
          >
            <Save size={20} className="group-hover:scale-110 transition-transform" />
            حفظ التغييرات
          </button>
        </div>
      </div>

      <div className="p-8 bg-amber-50 rounded-[2.5rem] border border-amber-100 flex gap-6">
        <div className="p-4 bg-white rounded-2xl shadow-sm text-amber-500 shrink-0">
          <Settings size={28} />
        </div>
        <div className="space-y-2">
           <h4 className="font-black text-amber-900">ملاحظة هامة حول البادئة</h4>
           <p className="text-xs text-amber-700/80 leading-relaxed font-bold">
             تغيير البادئة أو التسلسل يؤثر فقط على السجلات الجديدة المنشأة بعد الحفظ. السجلات القديمة ستحتفظ بأرقامها السابقة لضمان سلامة الأرشيف الورقي والقانوني للمخزن.
           </p>
        </div>
      </div>
    </div>
  );
};
