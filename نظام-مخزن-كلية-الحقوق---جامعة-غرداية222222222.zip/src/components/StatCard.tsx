import React from 'react';

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  color: 'indigo' | 'rose' | 'emerald' | 'amber' | 'blue' | 'teal';
}

const colorMap = {
  indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
  rose: 'bg-rose-50 text-rose-600 border-rose-100',
  emerald: 'bg-emerald-50 text-emerald-600 border-emerald-100',
  amber: 'bg-amber-50 text-amber-600 border-amber-100',
  blue: 'bg-blue-50 text-blue-600 border-blue-100',
  teal: 'bg-teal-50 text-teal-600 border-teal-100'
};

const StatCard: React.FC<StatCardProps> = ({ icon, label, value, color }) => {
  return (
    <div className="bg-white p-5 md:p-6 rounded-2xl shadow-sm border border-slate-200/60 flex items-center gap-4 hover:shadow-md transition-all duration-300 group">
      <div className={`p-3 md:p-4 rounded-xl transition-transform group-hover:scale-110 duration-300 ${colorMap[color]}`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] md:text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{label}</p>
        <p className="text-xl md:text-2xl font-black text-slate-900 font-mono">{value}</p>
      </div>
    </div>
  );
};

export default StatCard;
