import React, { useMemo, useState } from 'react';
import { 
  FileBox, 
  TrendingUp, 
  TrendingDown, 
  PieChart as PieIcon, 
  BarChart as BarIcon, 
  Calendar,
  Download,
  Printer,
  ChevronRight,
  ChevronLeft,
  Search
} from 'lucide-react';
import { 
  PieChart, Pie, Cell, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line
} from 'recharts';
import { useInventoryStore } from '../../store/inventoryStore';
import { cn, formatCurrency } from '../../lib/utils';
import { BrandingHeader } from '../ui/BrandingHeader';

export const DetailedReport: React.FC = () => {
  const { inventory, inboundLogs, outboundLogs } = useInventoryStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'consumption' | 'movements'>('overview');

  const categoryData = useMemo(() => {
    const cats: Record<string, number> = {};
    inventory.forEach(item => {
      cats[item.category] = (cats[item.category] || 0) + item.currentQty;
    });
    return Object.entries(cats).map(([name, value]) => ({ name, value }));
  }, [inventory]);

  const movementData = useMemo(() => {
    // Group monthly (simplified)
    return [
      { month: 'جانفي', inbound: 400, outbound: 240 },
      { month: 'فيفري', inbound: 300, outbound: 139 },
      { month: 'مارس', inbound: 200, outbound: 980 },
      { month: 'أفريل', inbound: 278, outbound: 390 },
    ];
  }, []);

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'];

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-5 duration-700">
      <BrandingHeader title="التقارير التحليلية" subtitle="مركز ذكاء الأعمال والرقابة المالية" />
      
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-6 py-3.5 bg-white border border-slate-200 rounded-2xl text-xs font-black text-slate-600 hover:border-indigo-400 hover:text-indigo-600 transition-all shadow-sm">
            <Download size={16} />
            تصدير البيانات (Excel)
          </button>
          <button className="flex items-center gap-2 px-6 py-3.5 bg-slate-900 text-white rounded-2xl text-xs font-black hover:bg-black transition-all shadow-xl shadow-slate-200">
            <Printer size={16} />
            طباعة التقرير الشامل
          </button>
        </div>
      </header>

      {/* Tabs Navigation */}
      <nav className="flex gap-1 p-1.5 bg-slate-100 rounded-[2rem] w-fit border border-slate-200/60">
        {[
          { id: 'overview', label: 'توزيع المخزون', icon: PieIcon },
          { id: 'consumption', label: 'تحليل الاستهلاك', icon: TrendingDown },
          { id: 'movements', label: 'حركة الاستلام', icon: TrendingUp },
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "px-8 py-3.5 rounded-full text-xs font-black transition-all flex items-center gap-2",
              activeTab === tab.id 
                ? "bg-white text-indigo-600 shadow-xl shadow-indigo-100/50" 
                : "text-slate-500 hover:text-slate-800"
            )}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Chart Area */}
        <div className="lg:col-span-8 bg-white rounded-[3rem] p-10 border border-slate-200/60 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8">
             <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
               <TrendingUp size={24} />
             </div>
          </div>
          
          <h3 className="text-xl font-black text-slate-800 mb-2">الرؤية البصرية للبيانات</h3>
          <p className="text-xs text-slate-400 font-bold mb-12 uppercase">تحليل ديناميكي بناءً على الفئات المختارة</p>

          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              {activeTab === 'overview' ? (
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={140}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {categoryData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 10px 40px -10px rgba(0,0,0,0.1)', background: '#fff' }}
                  />
                  <Legend iconType="circle" />
                </PieChart>
              ) : (
                <BarChart data={movementData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 700, fill: '#94a3b8' }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 700, fill: '#94a3b8' }} />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 10px 40px -10px rgba(0,0,0,0.1)', background: '#fff' }}
                  />
                  <Bar dataKey="inbound" name="وارد" fill="#6366f1" radius={[10, 10, 0, 0]} />
                  <Bar dataKey="outbound" name="صادر" fill="#f43f5e" radius={[10, 10, 0, 0]} />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>

        {/* Side Stats */}
        <div className="lg:col-span-4 space-y-6">
           <div className="bg-slate-900 rounded-[3rem] p-8 text-white">
             <div className="flex justify-between items-start mb-8">
               <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                 <FileBox size={24} className="text-indigo-400" />
               </div>
               <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400">القيمة الإجمالية</span>
             </div>
             <div className="space-y-1">
               <p className="text-3xl font-black">{formatCurrency(inventory.reduce((a, b) => a + (b.currentQty * (b.price || 0)), 0))}</p>
               <p className="text-slate-400 text-xs font-bold">تقدير القيمة السوقية للمخزون الحالي</p>
             </div>
             <div className="mt-8 pt-8 border-t border-white/10 flex items-center gap-4">
               <div className="flex-1">
                 <div className="flex justify-between text-[10px] font-black uppercase mb-2 text-slate-400">
                   <span>تغطية الميزانية</span>
                   <span>72%</span>
                 </div>
                 <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 w-[72%]"></div>
                 </div>
               </div>
             </div>
           </div>

           <div className="bg-emerald-50 border border-emerald-100 rounded-[2.5rem] p-8">
              <h4 className="text-emerald-900 font-black text-sm mb-6 flex items-center gap-2">
                <BarIcon size={16} />
                أعلى الفئات قيمة
              </h4>
              <div className="space-y-4">
                {categoryData.sort((a,b) => b.value - a.value).slice(0, 3).map((cat, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800">{cat.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-emerald-900">{cat.value} وحدة</span>
                    </div>
                  </div>
                ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
