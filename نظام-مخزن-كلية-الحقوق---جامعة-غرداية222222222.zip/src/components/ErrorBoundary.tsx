import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Critical System Failure:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC] p-6 text-center">
          <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-slate-200 space-y-6">
            <div className="w-20 h-20 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto animate-pulse-slow">
              <AlertTriangle size={40} />
            </div>
            <h1 className="text-2xl font-black text-slate-800">عذراً، حدث خطأ غير متوقع</h1>
            <p className="text-slate-500 text-sm leading-relaxed">
              لقد واجه النظام مشكلة تقنية مفاجئة. يرجى محاولة تحديث الصفحة أو الاتصال بالدعم الفني.
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-black transition-all shadow-lg"
            >
              إعادة تحميل الصفحة
            </button>
            {this.state.error && (
              <details className="mt-4 text-left p-4 bg-slate-50 rounded-xl border border-slate-100">
                <summary className="text-[10px] text-slate-400 cursor-pointer uppercase font-black">تفاصيل الخطأ التقني</summary>
                <code className="text-[10px] font-mono text-slate-600 mt-2 block break-all whitespace-pre-wrap p-2 bg-white rounded-lg">
                  {this.state.error.stack}
                </code>
              </details>
            )}
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
