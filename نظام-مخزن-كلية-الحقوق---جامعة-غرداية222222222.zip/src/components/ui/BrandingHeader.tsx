import React from 'react';

export const UniversityLogo: React.FC<{ className?: string }> = ({ className }) => {
  const [imgError, setImgError] = React.useState(false);

  if (!imgError) {
    return (
      <img 
        src="/logo-ug-center.png" 
        alt="شعار جامعة غرداية" 
        className={className} 
        onError={() => setImgError(true)}
        style={{ objectFit: 'contain' }}
      />
    );
  }

  return (
    <div className={`relative ${className} group`}>
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-md">
        {/* Outer Red Ring */}
        <circle cx="50" cy="50" r="48" fill="#e11d48" />
        <circle cx="50" cy="50" r="41" fill="white" />
        
        {/* Cyan/Blue Area */}
        <circle cx="50" cy="50" r="39" fill="#0ea5e9" />
        
        {/* Sun Rays */}
        <g stroke="white" strokeWidth="0.2" opacity="0.6">
          {[...Array(16)].map((_, i) => (
            <line 
              key={i}
              x1="50" y1="50" 
              x2={50 + 38 * Math.cos((i * 22.5 * Math.PI) / 180)} 
              y2={50 + 38 * Math.sin((i * 22.5 * Math.PI) / 180)} 
            />
          ))}
        </g>

        {/* Book (Open) */}
        <path d="M22 65 Q50 58 78 65 L78 80 Q50 72 22 80 Z" fill="white" stroke="#e11d48" strokeWidth="0.2" />
        <line x1="50" y1="63" x2="50" y2="76" stroke="#e11d48" strokeWidth="0.2" />

        {/* Minaret */}
        <path d="M47 32 L53 32 L54 62 L46 62 Z" fill="#78350f" />
        <path d="M44 28 H56 V32 H44 Z" fill="#78350f" />
        {/* 4 Horns */}
        <g stroke="#78350f" strokeWidth="1.2">
          <line x1="46" y1="23" x2="47" y2="28" />
          <line x1="49" y1="22" x2="49.5" y2="28" />
          <line x1="51" y1="22" x2="50.5" y2="28" />
          <line x1="54" y1="23" x2="53" y2="28" />
        </g>
        
        {/* Algeria Map (Green) */}
        <path 
          d="M50 82 L54 80 L58 76 L60 71 L58 66 L54 64 L50 63 L46 64 L42 66 L40 71 L42 76 L46 80 Z" 
          fill="#15803d" 
          stroke="#ffffff" 
          strokeWidth="0.4"
        />

        {/* Small Star on top */}
        <path d="M50 15 L51 17 H53 L51.5 18 L52 20 L50 19 L48 20 L48.5 18 L47 17 H49 Z" fill="#15803d" />

        {/* Curved Text */}
        <defs>
          <path id="univPathFinal3" d="M 50, 50 m -44.5, 0 a 44.5,44.5 0 1,1 89,0 a 44.5,44.5 0 1,1 -89,0" />
        </defs>
        <text fill="white" fontSize="4.2" fontWeight="900">
          <textPath href="#univPathFinal3" startOffset="25%" textAnchor="middle">جامعة غرداية</textPath>
          <textPath href="#univPathFinal3" startOffset="75%" textAnchor="middle">UNIVERSITY OF GHARDAIA</textPath>
        </text>
      </svg>
    </div>
  );
};

export const FacultyLogo: React.FC<{ className?: string }> = ({ className }) => {
  const [imgError, setImgError] = React.useState(false);

  if (!imgError) {
    return (
      <img 
        src="/fac-logo.png" 
        alt="شعار الكلية" 
        className={className} 
        onError={() => setImgError(true)}
        style={{ objectFit: 'contain' }}
      />
    );
  }

  return (
    <div className={`relative ${className} group`}>
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-md">
        {/* Outer Green Ring */}
        <circle cx="50" cy="50" r="48" fill="#15803d" />
        <circle cx="50" cy="50" r="41" fill="white" />
        
        {/* Content Area */}
        <circle cx="50" cy="50" r="39" fill="#f8fafc" />
        
        {/* Scales of Justice */}
        <g stroke="#e11d48" strokeWidth="1.8" fill="none" strokeLinecap="round">
          <path d="M50 28 V70" strokeWidth="2.5" />
          <path d="M25 42 Q50 35 75 42" strokeWidth="2" />
          
          {/* Scale Pans */}
          <g strokeWidth="1">
            <path d="M25 42 L18 60 H32 Z" fill="#e11d48" stroke="none" />
            <path d="M25 42 L18 60 M25 42 L32 60" />
            
            <path d="M75 42 L68 60 H82 Z" fill="#e11d48" stroke="none" />
            <path d="M75 42 L68 60 M75 42 L82 60" />
          </g>
        </g>

        {/* Pen Nib */}
        <path d="M50 28 L47 40 V58 L50 62 L53 58 V40 Z" fill="#e11d48" />
        <circle cx="50" cy="50" r="0.8" fill="#f8fafc" />
        <line x1="50" y1="50" x2="50" y2="60" stroke="#f8fafc" strokeWidth="0.4" />

        {/* Book Lines (Pages) at bottom */}
        <g stroke="#e11d48" strokeWidth="1.5" fill="none" strokeLinecap="round">
          <path d="M35 75 Q50 71 65 75" />
          <path d="M34 79 Q50 75 66 79" />
          <path d="M33 83 Q50 79 67 83" />
        </g>
        
        {/* White Stars */}
        <path d="M11 50 L12 51 L14 51 L12.5 52 L13 54 L11 53 L9 54 L9.5 52 L8 51 L10 51 Z" fill="white" />
        <path d="M89 50 L90 51 L92 51 L90.5 52 L91 54 L89 53 L87 54 L87.5 52 L86 51 L88 51 Z" fill="white" />

        {/* Curved Text */}
        <defs>
          <path id="facPathFinal3" d="M 50, 50 m -44.5, 0 a 44.5,44.5 0 1,1 89,0 a 44.5,44.5 0 1,1 -89,0" />
        </defs>
        <text fill="white" fontSize="4.2" fontWeight="900">
          <textPath href="#facPathFinal3" startOffset="25%" textAnchor="middle">جامعة غرداية</textPath>
          <textPath href="#facPathFinal3" startOffset="75%" textAnchor="middle">كلية الحقوق والعلوم السياسية</textPath>
        </text>
      </svg>
    </div>
  );
};

export const BrandingHeader: React.FC<{ 
  title?: string; 
  subtitle?: string;
  countryName?: string;
  orgName?: string;
  facultyName?: string;
}> = ({ 
  title, 
  subtitle, 
  countryName = "الجمهورية الجزائرية الديمقراطية الشعبية",
  orgName = "جامعة غرداية", 
  facultyName = "كلية الحقوق والعلوم السياسية"
}) => {
  return (
    <header className="w-full bg-white border-b-4 border-[#1e5631] shadow-[0_2px_5px_rgba(0,0,0,0.1)] py-5 px-[5%] flex flex-col md:flex-row items-center justify-between gap-6 mb-8 direction-rtl">
      {/* University Logo (Red) - Right in RTL */}
      <div className="flex-shrink-0 w-[150px] h-[150px] min-w-[100px] min-h-[100px] block">
        <UniversityLogo className="w-full h-full transition-all" />
      </div>
      
      <div className="text-center flex-grow space-y-1">
        <h1 className="text-[18px] md:text-[22px] font-bold text-[#1e5631] leading-tight">
          {countryName}
        </h1>
        <h2 className="text-[16px] md:text-[18px] font-bold text-[#333] leading-tight">
          {orgName}
        </h2>
        <p className="text-[14px] font-bold text-slate-800 leading-tight">
          {facultyName}
        </p>
        
        {subtitle && (
          <p className="text-[11px] md:text-xs font-bold text-slate-500 mt-2 bg-slate-50 inline-block px-3 py-1 rounded-full">{subtitle}</p>
        )}

        {title && (
           <div className="mt-4 block">
             <div className="inline-flex items-center gap-3 px-6 py-2.5 bg-indigo-50 text-indigo-700 rounded-2xl text-sm font-black border border-indigo-100/50 shadow-sm transition-all hover:bg-indigo-100/50">
               <div className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-pulse" />
               {title}
             </div>
           </div>
        )}
      </div>
      
      {/* Faculty Logo (Green) - Left in RTL */}
      <div className="flex-shrink-0 w-[150px] h-[150px] min-w-[100px] min-h-[100px] block">
        <FacultyLogo className="w-full h-full transition-all" />
      </div>
    </header>
  );
};
