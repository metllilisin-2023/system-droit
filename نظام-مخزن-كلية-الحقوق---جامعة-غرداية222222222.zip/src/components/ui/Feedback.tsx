import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, AlertCircle, Info, X, HelpCircle } from 'lucide-react';
import { useUIStore } from '../../store/uiStore';

export const Toast: React.FC = () => {
  const { toast, hideToast } = useUIStore();

  const icons = {
    success: <CheckCircle className="text-emerald-500" size={20} />,
    error: <AlertCircle className="text-rose-500" size={20} />,
    info: <Info className="text-indigo-500" size={20} />
  };

  const bgColors = {
    success: "bg-emerald-50 border-emerald-100",
    error: "bg-rose-50 border-rose-100",
    info: "bg-indigo-50 border-indigo-100"
  };

  return (
    <AnimatePresence>
      {toast.isVisible && (
        <motion.div 
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="fixed bottom-10 right-10 z-[300] flex items-center gap-4 px-6 py-4 bg-white border rounded-[2rem] shadow-2xl shadow-indigo-100/50"
        >
          <div className={bgColors[toast.type] + " p-3 rounded-2xl "}>
            {icons[toast.type]}
          </div>
          <span className="text-sm font-black text-slate-800 pr-2">{toast.message}</span>
          <button onClick={hideToast} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={18} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const ConfirmDialog: React.FC = () => {
  const { confirm, closeConfirm } = useUIStore();

  return (
    <AnimatePresence>
      {confirm.isOpen && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-md">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-white rounded-[3rem] shadow-2xl border border-white w-full max-w-md overflow-hidden"
          >
            <div className="p-10 space-y-8">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-20 h-20 bg-amber-50 text-amber-500 rounded-[2.5rem] flex items-center justify-center shadow-inner">
                  <HelpCircle size={40} />
                </div>
                <h3 className="text-2xl font-black text-slate-800">{confirm.title}</h3>
                <p className="text-slate-400 font-bold leading-relaxed">{confirm.message}</p>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => { confirm.onConfirm(); closeConfirm(); }}
                  className="flex-1 py-4 bg-slate-900 text-white rounded-2xl font-black shadow-xl shadow-slate-200 hover:bg-black transition-all"
                >
                  تأكيد الإجراء
                </button>
                <button 
                  onClick={closeConfirm}
                  className="flex-1 py-4 bg-slate-100 text-slate-500 rounded-2xl font-black hover:bg-slate-200 transition-all"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
