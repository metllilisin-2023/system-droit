import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={`relative flex items-center justify-center ${className} group`}>
      {/* Outer Circle (Green Border) */}
      <div className="absolute inset-0 bg-emerald-700 rounded-full shadow-lg border-4 border-white" />
      
      {/* Inner White Circle */}
      <div className="absolute inset-[10%] bg-white rounded-full flex items-center justify-center overflow-hidden border-2 border-emerald-800">
        <svg viewBox="0 0 100 100" className="w-[80%] h-[80%] text-rose-600 fill-current">
          {/* Scales of Justice */}
          <path d="M50 20 v60 M25 40 h50 M25 40 l-5 15 M75 40 l5 15 M20 55 a10 5 0 0 0 20 0 M60 55 a10 5 0 0 0 20 0" 
                stroke="currentColor" strokeWidth="2.5" fill="none" />
          
          {/* Pen / Nib */}
          <path d="M50 25 l-4 8 v15 l4 4 l4 -4 v-15 z" />
          <path d="M50 48 v8" stroke="currentColor" strokeWidth="1" />
          
          {/* Book at the bottom */}
          <path d="M30 75 q20 -5 40 0 v10 q-20 -5 -40 0 z" fill="currentColor" />
          <path d="M30 78 q20 -5 40 0" stroke="white" strokeWidth="0.5" fill="none" />
        </svg>
      </div>

      {/* Decorative Stars */}
      <div className="absolute top-[15%] left-[15%] text-white text-[8px]">★</div>
      <div className="absolute top-[15%] right-[15%] text-white text-[8px]">★</div>
      
      {/* Glowing Effect */}
      <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
  );
};
