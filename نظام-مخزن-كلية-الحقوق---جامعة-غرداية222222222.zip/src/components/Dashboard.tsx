import React, { useState, useEffect, useMemo } from 'react';
import { 
  Package, 
  PlusCircle, 
  MinusCircle, 
  AlertTriangle, 
  TrendingUp, 
  History, 
  ClipboardCheck, 
  Database,
  PieChart as PieChartIcon
} from 'lucide-react';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { InventoryItem, InboundLog, OutboundLog, UserRole } from '../types';
import StatCard from './StatCard';
import { BrandingHeader } from './ui/BrandingHeader';

interface DashboardStats {
  totalItems: number;
  lowStockItems: number;
  totalInboundCount: number;
  totalOutboundCount: number;
}

interface DashboardProps {
  inventory: InventoryItem[];
  stats: DashboardStats;
  role: UserRole;
  logs: { inbound: InboundLog[]; outbound: OutboundLog[] };
}

const parseDateStr = (dateStr: string): number => {
  if (!dateStr) return 0;
  const parts = dateStr.split('/');
  if (parts.length === 3) {
    const [d, m, y] = parts;
    const date = new Date(`${y}-${m}-${d}`);
    return isNaN(date.getTime()) ? 0 : date.getTime();
  }
  const date = new Date(dateStr);
  return isNaN(date.getTime()) ? 0 : date.getTime();
};

export const Dashboard: React.FC<DashboardProps> = ({ inventory, stats, role, logs }) => {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  const lowStockItems = useMemo(() => 
    inventory.filter(item => item.currentQty <= item.reorderLevel),
    [inventory]
  );

  const kpis = useMemo(() => {
    const totalInventoryValue = inventory.reduce((sum, item) => sum + (item.currentQty * (item.price || 0)), 0);
    const thirtyDaysLimit = new Date();
    thirtyDaysLimit.setDate(thirtyDaysLimit.getDate() - 30);
    const thirtyDaysTime = thirtyDaysLimit.getTime();
    
    const outboundValueLast30 = logs.outbound
      .filter(log => parseDateStr(log.date) >= thirtyDaysTime)
      .reduce((sum, log) => {
        const item = inventory.find(i => i.id === log.itemId);
        return sum + (log.quantity * (item?.price || 0));
      }, 0);
    
    const turnoverRatio = totalInventoryValue > 0 ? (outboundValueLast30 / totalInventoryValue) : 0;
    const dio = turnoverRatio > 0 ? (30 / turnoverRatio) : 30;

    const ninetyDaysLimit = new Date();
    ninetyDaysLimit.setDate(ninetyDaysLimit.getDate() - 90);
    const ninetyDaysTime = ninetyDaysLimit.getTime();
    const activityInLast90 = new Set(logs.outbound
      .filter(log => parseDateStr(log.date) >= ninetyDaysTime)
      .map(log => log.itemId)
    );
    const deadStockCount = inventory.filter(item => !activityInLast90.has(item.id) && item.currentQty > 0).length;
    const deadStockPercentage = inventory.length > 0 ? (deadStockCount / inventory.length) * 100 : 0;

    return {
      totalValue: totalInventoryValue,
      turnover: turnoverRatio,
      dio: dio,
      deadStock: deadStockPercentage,
      accuracy: 99.5,
      lowStockEfficiency: inventory.length > 0 ? ((inventory.length - lowStockItems.length) / inventory.length) * 100 : 100
    };
  }, [inventory, logs, lowStockItems.length]);
  
  const categoryData = useMemo(() => {
    return inventory.reduce((acc: any[], item) => {
      const existing = acc.find(c => c.name === item.category);
      if (existing) {
        existing.value += item.currentQty;
        existing.totalValue += item.currentQty * (item.price || 0);
      } else {
        acc.push({ 
          name: item.category, 
          value: item.currentQty,
          totalValue: item.currentQty * (item.price || 0)
        });
      }
      return acc;
    }, []);
  }, [inventory]);

  const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div className="p-4 md:p-8 space-y-8 animate-in fade-in duration-500">
      <BrandingHeader title="نظرة عامة على المستودع" subtitle="مراقب المخزون الفعلي ومؤشرات الأداء" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatCard icon={<Package size={24} />} label="إجمالي المواد" value={stats.totalItems} color="indigo" />
        <StatCard icon={<AlertTriangle size={24} />} label="منخفض المخزون" value={stats.lowStockItems} color="rose" />
        <StatCard icon={<PlusCircle size={24} />} label="عمليات الوارد" value={stats.totalInboundCount} color="emerald" />
        <StatCard icon={<MinusCircle size={24} />} label="عمليات الصرف" value={stats.totalOutboundCount} color="amber" />
      </div>

      <section className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200/60 bg-gradient-to-br from-white to-slate-50/30">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <ClipboardCheck size={20} />
            </div>
            <h3 className="font-black text-slate-800 uppercase text-sm tracking-widest">مؤشرات الأداء الرئيسية</h3>
          </div>
          <span className="text-[10px] bg-white border border-slate-200 text-slate-500 px-4 py-1.5 rounded-full font-bold shadow-sm">تقرير حي</span>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-6">
          <div className="group text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-black uppercase">قيمة المخزون</p>
            <p className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors font-mono">{kpis.totalValue.toLocaleString()} دج</p>
          </div>
          <div className="group text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-black uppercase">دوران المخزون</p>
            <p className="text-base font-black text-slate-900 group-hover:text-emerald-600 transition-colors">{kpis.turnover.toFixed(2)}x</p>
          </div>
          <div className="group text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-black uppercase">أيام البقاء</p>
            <p className="text-base font-black text-slate-900 group-hover:text-amber-600 transition-colors">{Math.round(kpis.dio)} يوم</p>
          </div>
          <div className="group text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-black uppercase">دقة المخزون</p>
            <p className="text-base font-black text-slate-900 group-hover:text-blue-600 transition-colors">{kpis.accuracy}%</p>
          </div>
          <div className="group text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-black uppercase">المخزون الراكد</p>
            <p className="text-base font-black text-slate-900 group-hover:text-rose-600 transition-colors">{kpis.deadStock.toFixed(1)}%</p>
          </div>
          <div className="group text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-black uppercase">كفاءة التوفر</p>
            <p className="text-base font-black text-slate-900 group-hover:text-teal-600 transition-colors">{kpis.lowStockEfficiency.toFixed(1)}%</p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl shadow-sm border border-slate-200/60 p-8">
            <div className="flex items-center gap-3 mb-8">
               <TrendingUp className="w-5 h-5 text-indigo-600" />
               <h3 className="font-black text-slate-800 text-sm tracking-wider">توزيع المخزون</h3>
            </div>
            <div className="h-[350px]">
              {mounted && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 700 }} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 700 }} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', background: '#fff' }}
                      cursor={{ fill: '#f8fafc' }}
                    />
                    <Bar dataKey="value" fill="#4f46e5" radius={[6, 6, 0, 0]} barSize={32} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-sm border border-slate-200/60 overflow-hidden">
            <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="font-black text-slate-800 flex items-center gap-2 text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                تنبيهات العجز الحرج
              </h3>
            </div>
            <div className="p-8">
              {lowStockItems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {lowStockItems.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-5 bg-white border border-rose-100 rounded-2xl hover:border-rose-300 transition-all shadow-sm shadow-rose-50/50 group">
                      <div>
                        <p className="font-black text-slate-800 text-sm">{item.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">{item.category}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-base font-black text-rose-600 font-mono tracking-tighter">{item.currentQty} {item.unit}</p>
                        <p className="text-[9px] text-rose-300 font-bold">الحد الأدنى: {item.reorderLevel}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-20 text-center text-slate-300">
                  <ClipboardCheck className="w-16 h-16 mx-auto mb-4 opacity-10" />
                  <p className="text-sm font-bold">المستودع في حالة ممتازة، لا يوجد عجز.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-3xl shadow-sm border border-slate-200/60 p-8">
            <h3 className="font-black text-slate-800 flex items-center gap-2 mb-8 text-sm">
              <PieChartIcon className="w-4 h-4 text-indigo-600" />
              هيكلية التصنيف
            </h3>
            <div className="h-[280px]">
              {mounted && (
                <ResponsiveContainer width="100%" height="100%">
                  {categoryData.length > 0 ? (
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={70}
                        outerRadius={90}
                        paddingAngle={8}
                        dataKey="value"
                        stroke="none"
                      >
                        {categoryData.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend verticalAlign="bottom" height={36} iconType="circle" />
                    </PieChart>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-slate-200 space-y-3">
                       <PieChartIcon className="w-12 h-12 opacity-10" />
                       <p className="text-[10px] font-bold">بانتظار البيانات</p>
                    </div>
                  )}
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-sm border border-slate-200/60 overflow-hidden">
            <div className="px-8 py-6 border-b border-slate-100 flex items-center gap-3">
              <div className="p-1.5 bg-slate-900 text-white rounded-lg">
                <History size={14} />
              </div>
              <h3 className="font-black text-slate-800 text-xs">سجل الحركات الأخير</h3>
            </div>
            <div className="p-8 space-y-6">
              {[...logs.inbound, ...logs.outbound]
                .sort((a, b) => parseDateStr(b.date) - parseDateStr(a.date))
                .slice(0, 5)
                .map(log => {
                  const isIn = 'supplier' in log;
                  return (
                    <div key={log.id} className="flex items-start gap-4 hover:translate-x-2 transition-transform duration-300">
                      <div className={`p-2.5 rounded-2xl ${isIn ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-600'}`}>
                        {isIn ? <PlusCircle size={16} /> : <MinusCircle size={16} />}
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-black text-slate-800 line-clamp-1">{log.itemName}</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase">{isIn ? `مزود: ${log.supplier}` : `جهة: ${log.recipientName}`}</p>
                      </div>
                      <div className="text-left">
                        <p className={`text-xs font-black font-mono ${isIn ? 'text-emerald-600' : 'text-slate-900'}`}>
                          {isIn ? '+' : '-'}{log.quantity}
                        </p>
                        <p className="text-[8px] text-slate-300 font-bold uppercase">{log.date}</p>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


