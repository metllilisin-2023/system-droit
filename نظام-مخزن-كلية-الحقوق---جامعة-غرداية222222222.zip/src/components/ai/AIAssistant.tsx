import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Send, Bot, User, Trash2, LayoutDashboard, Database, AlertTriangle } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { InventoryItem, InboundLog, OutboundLog } from '../../types';
import { useInventoryStore } from '../../store/inventoryStore';

export const AIAssistant: React.FC = () => {
  const { inventory, inboundLogs, outboundLogs } = useInventoryStore();
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'مرحباً بك في مركز التحليلات الذكي. أنا مساعدك الرقمي لجامعة غرداية. يمكنني تحليل المخزون، اقتراح طلبيات الشراء، أو الكشف عن الأنماط غير الاعتيادية في الصرف. كيف أخدمك اليوم؟' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const context = `
        Current Inventory Status: ${JSON.stringify(inventory.slice(0, 20))}
        Recent Inbounds: ${JSON.stringify(inboundLogs.slice(0, 5))}
        Recent Outbounds: ${JSON.stringify(outboundLogs.slice(0, 5))}
        Institution: University of Ghardaia, Faculty of Law.
        Language: Arabic.
        Tone: Professional, helpful, concise.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Context: ${context}\n\nClient Question: ${userMsg}`,
      });
      
      const responseText = response.text || "عذراً، لم أتمكن من توليد إجابة.";
      setMessages(prev => [...prev, { role: 'ai', text: responseText }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'ai', text: "عذراً، أواجه صعوبة في الاتصال حالياً. يرجى التأكد من مفتاح API أو المحاولة لاحقاً." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-[3rem] shadow-sm border border-slate-200/60 overflow-hidden animate-in fade-in duration-500">
      <header className="p-8 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-500 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Sparkles size={20} className="animate-pulse" />
          </div>
          <div>
            <h3 className="text-xl font-black tracking-tight">مساعد Gemini الذكي</h3>
            <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-widest">محلل البيانات الفوري</p>
          </div>
        </div>
        <button onClick={() => setMessages([messages[0]])} className="p-3 text-slate-400 hover:text-white transition-colors">
          <Trash2 size={18} />
        </button>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-8 bg-slate-50/50">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-start' : 'justify-end'} animate-in slide-in-from-bottom-2`}>
            <div className={`flex gap-4 max-w-[85%] ${m.role === 'user' ? 'flex-row' : 'flex-row-reverse'}`}>
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm ${
                m.role === 'user' ? 'bg-white text-slate-400 border border-slate-100' : 'bg-indigo-600 text-white'
              }`}>
                {m.role === 'user' ? <User size={18} /> : <Bot size={18} />}
              </div>
              <div className={`p-6 rounded-[2rem] text-sm leading-relaxed ${
                m.role === 'user' 
                  ? 'bg-white text-slate-800 border border-slate-200' 
                  : 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-100'
              }`}>
                {m.text}
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-end animate-pulse">
            <div className="bg-indigo-100 text-indigo-600 px-6 py-4 rounded-full flex gap-1">
              <span className="w-1 h-1 bg-current rounded-full animate-bounce"></span>
              <span className="w-1 h-1 bg-current rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-1 h-1 bg-current rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
          </div>
        )}
      </div>

      <footer className="p-8 bg-white border-t border-slate-100">
        <div className="relative group">
          <input 
            className="w-full pl-20 pr-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] outline-none focus:bg-white focus:border-indigo-400 focus:ring-4 focus:ring-indigo-50 transition-all text-sm font-bold"
            placeholder="اسأل عن أي مادة أو اطلب تقرير تحليل..."
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="absolute left-3 top-1/2 -translate-y-1/2 w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center hover:bg-black transition-all disabled:opacity-30 shadow-lg shadow-indigo-100"
          >
            <Send size={20} />
          </button>
        </div>
      </footer>
    </div>
  );
};
