import React, { useEffect, useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  PlusCircle, 
  MinusCircle, 
  History, 
  Settings, 
  Sparkles, 
  LogOut, 
  Menu, 
  X,
  Database,
  BarChart3,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Store & Utils
import { useInventoryStore } from './store/inventoryStore';
import { useUIStore } from './store/uiStore';
import { cn } from './lib/utils';

import { UniversityLogo, FacultyLogo } from './components/ui/BrandingHeader';

// Components
import ErrorBoundary from './components/ErrorBoundary';
import { Dashboard } from './components/Dashboard';
import { InventoryTable } from './components/inventory/InventoryTable';
import { TransactionManager } from './components/transactions/TransactionManager';
import { DetailedReport } from './components/reports/DetailedReport';
import { AIAssistant } from './components/ai/AIAssistant';
import { CategoryManager, SupplierManager } from './components/management/StructureManager';
import { SettingsManager } from './components/management/SettingsManager';
import { DevKit } from './components/management/DevKit';
import { Toast, ConfirmDialog } from './components/ui/Feedback';

import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './lib/firebase';
import { UserRole } from './types';

const App: React.FC = () => {
  const { 
    fetchData, 
    inventory, 
    suppliers, 
    inboundLogs, 
    outboundLogs, 
    categories, 
    addInboundLog, 
    addOutboundLog, 
    user, 
    setUser,
    deleteItem
  } = useInventoryStore();
  const { activeView, setActiveView, isSidebarOpen, setSidebarOpen } = useUIStore();

  useEffect(() => {
    fetchData();
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, [fetchData, setUser]);

  const dashboardStats = {
    totalItems: inventory.length,
    lowStockItems: inventory.filter(i => i.currentQty <= i.reorderLevel).length,
    totalInboundCount: inboundLogs.length,
    totalOutboundCount: outboundLogs.length
  };

  const navItems = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
    { id: 'inventory', label: 'المخزن العام', icon: Package },
    { id: 'inbound', label: 'تسجيل وارد', icon: PlusCircle },
    { id: 'outbound', label: 'صرف مواد', icon: MinusCircle },
    { id: 'reports', label: 'التقارير', icon: BarChart3 },
    { id: 'ai', label: 'المساعد الذكي', icon: Sparkles },
    { id: 'history', label: 'سجل الحركات', icon: History },
    { id: 'categories', label: 'الفئات', icon: Database },
    { id: 'suppliers', label: 'الموردين', icon: FileText },
    { id: 'settings', label: 'إعدادات البادئة', icon: Settings },
    { id: 'devkit', label: 'صيانة النظام', icon: Database },
  ];

  const renderView = () => {
    const commonDashboardProps = {
      inventory,
      stats: dashboardStats,
      role: UserRole.STOREKEEPER,
      logs: { inbound: inboundLogs, outbound: outboundLogs }
    };

    switch (activeView) {
      case 'dashboard': 
        return <Dashboard {...commonDashboardProps} />;
      case 'inventory': 
        return <InventoryTable 
          inventory={inventory} 
          role={UserRole.STOREKEEPER} 
          categories={categories} 
          isAdmin={true}
          onAddItem={() => {}}
          onEditItem={() => {}}
          onDeleteItem={deleteItem}
          onShowBarcode={() => {}}
        />;
      case 'inbound': return <TransactionManager type="inbound" inventory={inventory} suppliers={suppliers} onAddInbound={addInboundLog} onAddOutbound={addOutboundLog} />;
      case 'outbound': return <TransactionManager type="outbound" inventory={inventory} suppliers={suppliers} onAddInbound={addInboundLog} onAddOutbound={addOutboundLog} />;
      case 'reports': return <DetailedReport />;
      case 'ai': return <AIAssistant />;
      case 'categories': return <CategoryManager />;
      case 'suppliers': return <SupplierManager />;
      case 'settings': return <SettingsManager />;
      case 'devkit': return <DevKit />;
      default: return <Dashboard {...commonDashboardProps} />;
    }
  };

  return (
    <ErrorBoundary>
      <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-indigo-100 selection:text-indigo-900 overflow-hidden" dir="rtl">
        {/* Sidebar */}
        <aside className={cn(
          "fixed inset-y-0 right-0 z-50 w-72 bg-white border-l border-slate-200 transition-transform duration-500 ease-in-out lg:translate-x-0",
          !isSidebarOpen && "translate-x-full lg:translate-x-0"
        )}>
          <div className="flex flex-col h-full p-6">
            <header className="mb-10">
              <div className="flex flex-col items-center text-center gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <FacultyLogo className="w-16 h-16" />
                  <UniversityLogo className="w-16 h-16" />
                </div>
                <div>
                  <h1 className="text-lg font-black tracking-tight leading-tight">جامعة غرداية</h1>
                  <p className="text-[11px] text-slate-500 font-bold leading-none mt-1">كلية الحقوق والعلوم السياسية</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">نظام التسيير الرقمي للمخزن</p>
                </div>
              </div>
              <div className="h-px bg-slate-100" />
            </header>

            <nav className="flex-1 space-y-1.5 -mx-2 overflow-y-auto no-scrollbar">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setActiveView(item.id as any); setSidebarOpen(false); }}
                  className={cn(
                    "w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl text-sm font-black transition-all group",
                    activeView === item.id 
                      ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" 
                      : "text-slate-400 hover:bg-slate-50 hover:text-slate-900"
                  )}
                >
                  <item.icon size={20} className={cn(
                    "transition-transform group-hover:scale-110",
                    activeView === item.id ? "text-white" : "text-slate-300 group-hover:text-slate-900"
                  )} />
                  {item.label}
                  {activeView === item.id && (
                    <motion.div layoutId="nav-indicator" className="mr-auto w-1.5 h-1.5 bg-white rounded-full" />
                  )}
                </button>
              ))}
            </nav>

            <footer className="mt-8 pt-8 border-t border-slate-100">
              <div className="p-5 bg-slate-50 rounded-3xl border border-slate-100">
                 <div className="flex items-center gap-4 mb-1">
                    <div className="w-10 h-10 bg-white border border-slate-200 rounded-2xl flex items-center justify-center text-indigo-600 font-black text-xs">
                      {user?.displayName?.[0] || 'A'}
                    </div>
                    <div className="flex-1 truncate">
                       <p className="text-xs font-black text-slate-800 truncate">{user?.displayName || 'مسؤول النظام'}</p>
                       <p className="text-[9px] text-slate-400 font-bold uppercase truncate">{user?.email}</p>
                    </div>
                 </div>
                 <button className="w-full mt-4 flex items-center justify-center gap-2 py-2.5 text-[10px] font-black text-rose-500 hover:bg-rose-50 rounded-xl transition-all">
                    <LogOut size={14} />
                    تسجيل الخروج
                 </button>
              </div>
            </footer>
          </div>
        </aside>

        {/* Global Overlay for Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm lg:hidden" 
            />
          )}
        </AnimatePresence>

        {/* Main Content */}
        <main className="flex-1 lg:pr-72 min-h-screen flex flex-col relative">
          {/* Header Bar */}
          <header className="sticky top-0 z-30 h-20 bg-slate-50/80 backdrop-blur-xl border-b border-transparent flex items-center justify-between px-10">
            <div className="flex items-center gap-6">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="p-3 bg-white border border-slate-200 rounded-xl lg:hidden text-slate-600"
              >
                <Menu size={20} />
              </button>
              <nav className="hidden md:flex gap-2">
                 <div className="px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-[10px] font-black uppercase tracking-widest">
                   نظام التسيير المستقر V3.0
                 </div>
                 <div className="px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-black uppercase tracking-widest">
                   الربط السحابي: متصل
                 </div>
              </nav>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden sm:block text-left">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">حالة التخزين</p>
                <p className="text-sm font-black text-slate-800">7.2 GB / 10 GB</p>
              </div>
              <div className="w-10 h-10 bg-slate-200 rounded-xl animate-pulse" />
            </div>
          </header>

          {/* Viewport */}
          <div className="flex-1 p-10 max-h-[calc(100vh-80px)] overflow-y-auto no-scrollbar">
            <div className="max-w-7xl mx-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeView}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                >
                  {renderView()}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </main>
        
        {/* Global Components */}
        <Toast />
        <ConfirmDialog />
      </div>
    </ErrorBoundary>
  );
};

export default App;
