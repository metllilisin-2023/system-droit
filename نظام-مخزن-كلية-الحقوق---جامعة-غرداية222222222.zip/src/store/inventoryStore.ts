import { create } from 'zustand';
import { InventoryItem, InboundLog, OutboundLog, Category, AuditLog, Supplier, SystemSettings } from '../types';
import { db, auth, handleFirestoreError } from '../lib/firebase';
import { 
  collection, 
  getDocs, 
  setDoc, 
  doc, 
  deleteDoc, 
  updateDoc, 
  query, 
  orderBy, 
  limit, 
  writeBatch,
  where,
  serverTimestamp
} from 'firebase/firestore';

interface InventoryState {
  inventory: InventoryItem[];
  inboundLogs: InboundLog[];
  outboundLogs: OutboundLog[];
  categories: Category[];
  suppliers: Supplier[];
  auditLogs: AuditLog[];
  systemSettings: SystemSettings | null;
  loading: boolean;
  error: string | null;
  user: any | null;
  
  fetchData: () => Promise<void>;
  setUser: (user: any | null) => void;
  
  addItem: (item: InventoryItem) => Promise<void>;
  updateItem: (item: InventoryItem) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  
  addInboundLog: (log: InboundLog) => Promise<void>;
  addOutboundLog: (log: OutboundLog) => Promise<void>;
  addAuditLog: (log: AuditLog) => Promise<void>;
  
  addCategory: (category: Category) => Promise<void>;
  updateCategory: (category: Category) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;

  addSupplier: (supplier: Supplier) => Promise<void>;
  updateSupplier: (supplier: Supplier) => Promise<void>;
  deleteSupplier: (id: string) => Promise<void>;

  updateSettings: (settings: Partial<SystemSettings>) => Promise<void>;
  generateInventoryNo: (categoryPrefix?: string) => string;
  
  importData: (data: Partial<InventoryState>) => Promise<void>;
  exportDataToDisk: () => void;
  clearAllData: () => Promise<void>;
  sanitizeLogs: () => void;
}

const STORAGE_KEY = 'law_inventory_v3_disk_cache';

const getLocalStorageData = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return null;
    const parsed = JSON.parse(data);
    
    // Safety check: ensure structure matches what we expect
    if (typeof parsed !== 'object') return null;
    
    return {
      inventory: Array.isArray(parsed.inventory) ? parsed.inventory : [],
      inboundLogs: Array.isArray(parsed.inboundLogs) ? parsed.inboundLogs : [],
      outboundLogs: Array.isArray(parsed.outboundLogs) ? parsed.outboundLogs : [],
      categories: Array.isArray(parsed.categories) ? parsed.categories : [],
      suppliers: Array.isArray(parsed.suppliers) ? parsed.suppliers : [],
      auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
      systemSettings: parsed.systemSettings || null,
    };
  } catch (err) {
    console.error("Critical: Local Storage Check Failed", err);
    return null;
  }
};

const saveToLocalStorage = (state: Partial<InventoryState>) => {
  try {
    const current = getLocalStorageData() || {
      inventory: [],
      inboundLogs: [],
      outboundLogs: [],
      categories: [],
      suppliers: [],
      auditLogs: []
    };
    
    // Data Truncation: Keep only last 500 logs locally to save disk space (Constitution Rule)
    const MAX_LOCAL_LOGS = 500;
    
    const updated = { 
      ...current, 
      ...state,
      inboundLogs: (state.inboundLogs || current.inboundLogs || []).slice(-MAX_LOCAL_LOGS),
      outboundLogs: (state.outboundLogs || current.outboundLogs || []).slice(-MAX_LOCAL_LOGS),
      auditLogs: (state.auditLogs || current.auditLogs || []).slice(-MAX_LOCAL_LOGS),
    };
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error("Local Disk Write Protection Error:", err);
  }
};

const toDocId = (id: string) => id.replace(/\//g, '_');

export const useInventoryStore = create<InventoryState>((set, get) => ({
  inventory: [],
  inboundLogs: [],
  outboundLogs: [],
  categories: [],
  suppliers: [],
  auditLogs: [],
  systemSettings: null,
  loading: false,
  error: null,
  user: null,

  setUser: (user) => set({ user }),

  exportDataToDisk: () => {
    try {
      const data = {
        inventory: get().inventory,
        inboundLogs: get().inboundLogs,
        outboundLogs: get().outboundLogs,
        categories: get().categories,
        suppliers: get().suppliers,
        auditLogs: get().auditLogs,
        exportDate: new Date().toISOString(),
        version: "3.0"
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const date = new Date().toISOString().split('T')[0];
      link.href = url;
      link.download = `نسخة_احتياطية_المخزن_${date}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Export Failed:", err);
      alert("فشل تصدير البيانات إلى القرص الصلب.");
    }
  },
  
  fetchData: async () => {
    set({ loading: true, error: null });
    
    if (!auth.currentUser) {
      const localData = getLocalStorageData();
      if (localData) {
        set({
          inventory: localData.inventory || [],
          inboundLogs: localData.inboundLogs || [],
          outboundLogs: localData.outboundLogs || [],
          categories: localData.categories || [],
          suppliers: localData.suppliers || [],
          auditLogs: localData.auditLogs || [],
          loading: false
        });
      } else {
        set({ loading: false });
      }
      return;
    }

    try {
      const getCollectionDocs = async (collName: string, queryRef?: any) => {
        try {
          return await getDocs(queryRef || collection(db, collName));
        } catch (error: any) {
          if (error.code === 'permission-denied') {
            console.warn(`Permission denied for collection: ${collName}. Skipping.`);
            return { docs: [] };
          }
          throw error;
        }
      };

      const [
        invSnap,
        inSnap,
        outSnap,
        catSnap,
        supSnap,
        auditSnap,
        settingsSnap
      ] = await Promise.all([
        getCollectionDocs('inventory'),
        getCollectionDocs('inbound_logs'),
        getCollectionDocs('outbound_logs'),
        getCollectionDocs('categories'),
        getCollectionDocs('suppliers'),
        getCollectionDocs('audit_logs', query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc'), limit(100))),
        getCollectionDocs('system_settings', query(collection(db, 'system_settings'), limit(1)))
      ]);

      const settings = settingsSnap.docs.length > 0 
        ? settingsSnap.docs[0].data() as SystemSettings 
        : {
            id: 'default',
            globalPrefix: 'UNIV-GHA-LAW',
            includeYear: true,
            nextSequence: 1001
          } as SystemSettings;

      set({
        inventory: invSnap.docs.map(doc => doc.data() as InventoryItem),
        inboundLogs: inSnap.docs.map(doc => doc.data() as InboundLog),
        outboundLogs: outSnap.docs.map(doc => doc.data() as OutboundLog),
        categories: catSnap.docs.map(doc => doc.data() as Category),
        suppliers: supSnap.docs.map(doc => doc.data() as Supplier),
        auditLogs: auditSnap.docs.map(doc => doc.data() as AuditLog),
        systemSettings: settings,
        loading: false
      });
      
      get().sanitizeLogs();
    } catch (error: any) {
      console.error("Fetch Data Error:", error);
      handleFirestoreError(error, 'list');
      set({ error: error.message, loading: false });
    }
  },

  clearAllData: async () => {
    set({ loading: true, error: null });
    if (!auth.currentUser) {
      localStorage.removeItem('inventory_app_data');
      set({
        inventory: [],
        inboundLogs: [],
        outboundLogs: [],
        categories: [],
        suppliers: [],
        auditLogs: [],
        systemSettings: {
          id: 'default',
          globalPrefix: 'UNIV-GHA-LAW',
          includeYear: true,
          nextSequence: 1001
        },
        loading: false
      });
      return;
    }

    try {
      const batch = writeBatch(db);
      const state = get();
      
      state.inventory.forEach(item => batch.delete(doc(db, 'inventory', toDocId(item.id))));
      state.inboundLogs.forEach(log => batch.delete(doc(db, 'inbound_logs', toDocId(log.id))));
      state.outboundLogs.forEach(log => batch.delete(doc(db, 'outbound_logs', toDocId(log.id))));
      state.categories.forEach(cat => batch.delete(doc(db, 'categories', toDocId(cat.id))));
      state.suppliers.forEach(sup => batch.delete(doc(db, 'suppliers', toDocId(sup.id))));
      state.auditLogs.forEach(log => batch.delete(doc(db, 'audit_logs', toDocId(log.id))));
      
      // Also reset settings
      batch.delete(doc(db, 'system_settings', 'default'));

      await batch.commit();
      set({
        inventory: [],
        inboundLogs: [],
        outboundLogs: [],
        categories: [],
        suppliers: [],
        auditLogs: [],
        systemSettings: {
          id: 'default',
          globalPrefix: 'UNIV-GHA-LAW',
          includeYear: true,
          nextSequence: 1001
        },
        loading: false
      });
    } catch (error: any) {
      handleFirestoreError(error, 'write');
    }
  },

  importData: async (data: Partial<InventoryState>) => {
    set({ loading: true, error: null });
    
    if (!auth.currentUser) {
      if (!data.inventory || !data.categories) {
        throw new Error('تنسيق ملف النسخة الاحتياطية غير صالح.');
      }
      saveToLocalStorage(data);
      set({ 
        inventory: data.inventory || [],
        inboundLogs: data.inboundLogs || [],
        outboundLogs: data.outboundLogs || [],
        categories: data.categories || [],
        suppliers: data.suppliers || [],
        auditLogs: data.auditLogs || [],
        loading: false 
      });
      return;
    }

    try {
      if (!data.inventory || !data.categories) {
        throw new Error('تنسيق ملف النسخة الاحتياطية غير صالح.');
      }

      const batch = writeBatch(db);

      data.categories.forEach((cat: Category) => {
        batch.set(doc(db, 'categories', toDocId(cat.id)), cat);
      });

      data.inventory.forEach((item: InventoryItem) => {
        batch.set(doc(db, 'inventory', toDocId(item.id)), item);
      });

      if (data.inboundLogs) {
        data.inboundLogs.forEach((log: InboundLog) => {
          batch.set(doc(db, 'inbound_logs', toDocId(log.id)), log);
        });
      }

      if (data.outboundLogs) {
        data.outboundLogs.forEach((log: OutboundLog) => {
          batch.set(doc(db, 'outbound_logs', toDocId(log.id)), log);
        });
      }

      if (data.suppliers) {
        data.suppliers.forEach((sup: Supplier) => {
          batch.set(doc(db, 'suppliers', toDocId(sup.id)), sup);
        });
      }

      if (data.auditLogs) {
        data.auditLogs.forEach((log: AuditLog) => {
          batch.set(doc(db, 'audit_logs', toDocId(log.id)), log);
        });
      }

      await batch.commit();
      await get().fetchData();
    } catch (error: any) {
      handleFirestoreError(error, 'write');
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  sanitizeLogs: () => {
    const { inboundLogs, outboundLogs, auditLogs } = get();
    
    const isValidLog = (log: any) => {
      return log && 
             log.id && 
             log.itemId && 
             log.itemName && 
             log.date && 
             log.quantity != null &&
             !isNaN(Number(log.quantity));
    };

    const sanitizedInbound = (inboundLogs || []).filter(isValidLog);
    const sanitizedOutbound = (outboundLogs || []).filter(isValidLog);
    const sanitizedAudit = (auditLogs || []).filter(log => log && log.id && log.timestamp);

    if (
      sanitizedInbound.length !== (inboundLogs || []).length || 
      sanitizedOutbound.length !== (outboundLogs || []).length ||
      sanitizedAudit.length !== (auditLogs || []).length
    ) {
      console.warn("Sanitized logs: Removed corrupted entries.");
      set({
        inboundLogs: sanitizedInbound,
        outboundLogs: sanitizedOutbound,
        auditLogs: sanitizedAudit
      });
      saveToLocalStorage(get());
    }
  },
  
  addItem: async (item) => {
    if (!auth.currentUser) {
      const inventory = [...get().inventory, item];
      set({ inventory });
      saveToLocalStorage({ inventory });
      return;
    }
    try {
      const itemWithMeta = {
        ...item,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        createdBy: auth.currentUser.uid
      };
      await setDoc(doc(db, 'inventory', toDocId(item.id)), itemWithMeta);
      set((state) => ({ inventory: [...state.inventory, item] }));
    } catch (error: any) {
      handleFirestoreError(error, 'create', `inventory/${item.id}`);
    }
  },
  
  updateItem: async (updatedItem: InventoryItem) => {
    if (!auth.currentUser) {
      const inventory = get().inventory.map(item => item.id === updatedItem.id ? updatedItem : item);
      set({ inventory });
      saveToLocalStorage({ inventory });
      return;
    }
    try {
      const { createdAt, createdBy, ...updateData } = updatedItem as Partial<InventoryItem>;
      await updateDoc(doc(db, 'inventory', toDocId(updatedItem.id)), {
        ...updateData,
        updatedAt: serverTimestamp()
      });
      set((state) => ({
        inventory: state.inventory.map(item => item.id === updatedItem.id ? updatedItem : item)
      }));
    } catch (error: any) {
      handleFirestoreError(error, 'update', `inventory/${updatedItem.id}`);
    }
  },
  
  deleteItem: async (id) => {
    if (!auth.currentUser) {
      const inventory = get().inventory.filter(item => item.id !== id);
      set({ inventory });
      saveToLocalStorage({ inventory });
      return;
    }
    try {
      await deleteDoc(doc(db, 'inventory', toDocId(id)));
      set((state) => ({
        inventory: state.inventory.filter(item => item.id !== id)
      }));
    } catch (error: any) {
      handleFirestoreError(error, 'delete', `inventory/${id}`);
    }
  },
  
  addInboundLog: async (log) => {
    if (!auth.currentUser) {
      const inboundLogs = [...get().inboundLogs, log];
      set({ inboundLogs });
      saveToLocalStorage({ inboundLogs });
      return;
    }
    try {
      const batch = writeBatch(db);
      const logWithMeta = {
        ...log,
        createdAt: serverTimestamp(),
        createdBy: auth.currentUser.uid
      };
      batch.set(doc(db, 'inbound_logs', toDocId(log.id)), logWithMeta);
      
      const item = get().inventory.find(i => i.id === log.itemId);
      const netQuantity = log.quantity * (log.conversionRate || 1);
      
      if (item) {
        batch.update(doc(db, 'inventory', toDocId(item.id)), {
          currentQty: item.currentQty + netQuantity,
          inbound: (item.inbound || 0) + netQuantity,
          updatedAt: serverTimestamp()
        });
      }
      
      await batch.commit();
      
      const MAX_LOGS = 500;
      set((state) => {
        const newLogs = [...state.inboundLogs, log];
        const slicedLogs = newLogs.length > MAX_LOGS ? newLogs.slice(-MAX_LOGS) : newLogs;
        
        return { 
          inboundLogs: slicedLogs,
          inventory: state.inventory.map(i => i.id === log.itemId ? {
            ...i,
            currentQty: i.currentQty + netQuantity,
            inbound: (i.inbound || 0) + netQuantity
          } : i)
        };
      });
    } catch (error: any) {
      handleFirestoreError(error, 'create', `inbound_logs/${log.id}`);
    }
  },
  
  addOutboundLog: async (log) => {
    if (!auth.currentUser) {
      const outboundLogs = [...get().outboundLogs, log];
      set({ outboundLogs });
      saveToLocalStorage({ outboundLogs });
      return;
    }
    try {
      const batch = writeBatch(db);
      const logWithMeta = {
        ...log,
        createdAt: serverTimestamp(),
        createdBy: auth.currentUser.uid
      };
      batch.set(doc(db, 'outbound_logs', toDocId(log.id)), logWithMeta);
      
      const item = get().inventory.find(i => i.id === log.itemId);
      const netQuantity = log.quantity * (log.conversionRate || 1);

      if (item) {
        batch.update(doc(db, 'inventory', toDocId(item.id)), {
          currentQty: item.currentQty - netQuantity,
          outbound: (item.outbound || 0) + netQuantity,
          updatedAt: serverTimestamp()
        });
      }
      
      await batch.commit();
      
      const MAX_LOGS = 500;
      set((state) => {
        const newLogs = [...state.outboundLogs, log];
        const slicedLogs = newLogs.length > MAX_LOGS ? newLogs.slice(-MAX_LOGS) : newLogs;
        
        return { 
          outboundLogs: slicedLogs,
          inventory: state.inventory.map(i => i.id === log.itemId ? {
            ...i,
            currentQty: i.currentQty - netQuantity,
            outbound: (i.outbound || 0) + netQuantity
          } : i)
        };
      });
    } catch (error: any) {
      handleFirestoreError(error, 'create', `outbound_logs/${log.id}`);
    }
  },
  
  addAuditLog: async (log) => {
    if (!auth.currentUser) {
      const auditLogs = [...get().auditLogs, log];
      set({ auditLogs });
      saveToLocalStorage({ auditLogs });
      return;
    }
    try {
      await setDoc(doc(db, 'audit_logs', toDocId(log.id)), log);
      set((state) => ({ auditLogs: [...state.auditLogs, log] }));
    } catch (error: any) {
      handleFirestoreError(error, 'create', `audit_logs/${log.id}`);
    }
  },
  
  addCategory: async (category) => {
    if (!auth.currentUser) {
      const categories = [...get().categories, category];
      set({ categories });
      saveToLocalStorage({ categories });
      return;
    }
    try {
      const catWithMeta = {
        ...category,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        createdBy: auth.currentUser.uid
      };
      await setDoc(doc(db, 'categories', toDocId(category.id)), catWithMeta);
      set((state) => ({ categories: [...state.categories, category] }));
    } catch (error: any) {
      handleFirestoreError(error, 'create', `categories/${category.id}`);
    }
  },
  
  updateCategory: async (category) => {
    if (!auth.currentUser) {
      const categories = get().categories.map(c => c.id === category.id ? category : c);
      set({ categories });
      saveToLocalStorage({ categories });
      return;
    }
    try {
      const { createdAt, createdBy, ...updateData } = category as any;
      await updateDoc(doc(db, 'categories', toDocId(category.id)), {
        ...updateData,
        updatedAt: serverTimestamp()
      });
      set((state) => ({
        categories: state.categories.map(c => c.id === category.id ? category : c)
      }));
    } catch (error: any) {
      handleFirestoreError(error, 'update', `categories/${category.id}`);
    }
  },
  
  deleteCategory: async (id) => {
    if (!auth.currentUser) {
      const categories = get().categories.filter(c => c.id !== id);
      set({ categories });
      saveToLocalStorage({ categories });
      return;
    }
    try {
      await deleteDoc(doc(db, 'categories', toDocId(id)));
      set((state) => ({
        categories: state.categories.filter(c => c.id !== id)
      }));
    } catch (error: any) {
      handleFirestoreError(error, 'delete', `categories/${id}`);
    }
  },

  addSupplier: async (supplier) => {
    if (!auth.currentUser) {
      const suppliers = [...get().suppliers, supplier];
      set({ suppliers });
      saveToLocalStorage({ suppliers });
      return;
    }
    try {
      const supWithMeta = {
        ...supplier,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        createdBy: auth.currentUser.uid
      };
      await setDoc(doc(db, 'suppliers', toDocId(supplier.id)), supWithMeta);
      set((state) => ({ suppliers: [...state.suppliers, supplier] }));
    } catch (error: any) {
      handleFirestoreError(error, 'create', `suppliers/${supplier.id}`);
    }
  },
  
  updateSupplier: async (supplier) => {
    if (!auth.currentUser) {
      const suppliers = get().suppliers.map(s => s.id === supplier.id ? supplier : s);
      set({ suppliers });
      saveToLocalStorage({ suppliers });
      return;
    }
    try {
      const { createdAt, createdBy, ...updateData } = supplier as any;
      await updateDoc(doc(db, 'suppliers', toDocId(supplier.id)), {
        ...updateData,
        updatedAt: serverTimestamp()
      });
      set((state) => ({
        suppliers: state.suppliers.map(s => s.id === supplier.id ? supplier : s)
      }));
    } catch (error: any) {
      handleFirestoreError(error, 'update', `suppliers/${supplier.id}`);
    }
  },
  
  deleteSupplier: async (id) => {
    if (!auth.currentUser) {
      const suppliers = get().suppliers.filter(s => s.id !== id);
      set({ suppliers });
      saveToLocalStorage({ suppliers });
      return;
    }
    try {
      await deleteDoc(doc(db, 'suppliers', toDocId(id)));
      set((state) => ({
        suppliers: state.suppliers.filter(s => s.id !== id)
      }));
    } catch (error: any) {
      handleFirestoreError(error, 'delete', `suppliers/${id}`);
    }
  },

  updateSettings: async (settings) => {
    const current = get().systemSettings || {
      id: 'default',
      globalPrefix: 'UNIV-GHA-LAW',
      includeYear: true,
      nextSequence: 1001
    };

    const updated = { ...current, ...settings, lastUpdated: new Date().toISOString() };
    
    if (!auth.currentUser) {
      set({ systemSettings: updated });
      saveToLocalStorage({ systemSettings: updated });
      return;
    }

    try {
      await setDoc(doc(db, 'system_settings', 'default'), updated);
      set({ systemSettings: updated });
    } catch (error: any) {
      handleFirestoreError(error, 'update', 'system_settings/default');
    }
  },

  generateInventoryNo: (categoryPrefix) => {
    const settings = get().systemSettings;
    if (!settings) return '';

    const year = settings.includeYear ? new Date().getFullYear().toString().slice(-2) : '';
    const parts = [settings.globalPrefix];
    
    if (categoryPrefix) parts.push(categoryPrefix);
    if (year) parts.push(year);
    
    parts.push(settings.nextSequence.toString());
    
    return parts.join('-');
  },
}));

