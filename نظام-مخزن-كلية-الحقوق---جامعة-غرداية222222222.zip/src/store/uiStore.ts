import { create } from 'zustand';

export type ToastType = 'success' | 'error' | 'info';
export type AppView = 'dashboard' | 'inventory' | 'inbound' | 'outbound' | 'reports' | 'ai' | 'history' | 'categories' | 'suppliers' | 'settings' | 'devkit';

interface UIState {
  // Navigation
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  isSidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;

  // Toast
  toast: {
    isVisible: boolean;
    message: string;
    type: ToastType;
  };
  showToast: (message: string, type?: ToastType) => void;
  hideToast: () => void;

  // Confirm Dialog
  confirm: {
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  };
  openConfirm: (title: string, message: string, onConfirm: () => void) => void;
  closeConfirm: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  activeView: 'dashboard',
  setActiveView: (view) => set({ activeView: view }),
  isSidebarOpen: false,
  setSidebarOpen: (open) => set({ isSidebarOpen: open }),

  toast: {
    isVisible: false,
    message: '',
    type: 'success',
  },
  showToast: (message, type = 'success') => {
    set({ toast: { isVisible: true, message, type } });
    setTimeout(() => {
      set((state) => ({ toast: { ...state.toast, isVisible: false } }));
    }, 4000);
  },
  hideToast: () => {
    set((state) => ({ toast: { ...state.toast, isVisible: false } }));
  },

  confirm: {
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  },
  openConfirm: (title, message, onConfirm) => {
    set({ confirm: { isOpen: true, title, message, onConfirm } });
  },
  closeConfirm: () => {
    set((state) => ({ confirm: { ...state.confirm, isOpen: false } }));
  },
}));
