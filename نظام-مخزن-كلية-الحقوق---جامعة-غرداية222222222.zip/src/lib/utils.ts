import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * دمج فئات Tailwind CSS بشكل آمن
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * تحليل تاريخ DD/MM/YYYY للفرز أو المعالجة
 */
export const parseDateStr = (dateStr: string): number => {
  if (!dateStr) return 0;
  try {
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      const [d, m, y] = parts;
      const date = new Date(`${y}-${m}-${d}`);
      return isNaN(date.getTime()) ? 0 : date.getTime();
    }
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? 0 : date.getTime();
  } catch (e) {
    return 0;
  }
};

/**
 * حماية مصفوفات البيانات من قيم undefined أو null
 * الدستور البرمجي: 1.3
 */
export function safeMap<T, R>(data: T[] | undefined | null, callback: (item: T, index: number) => R): R[] {
  return (data ?? []).map(callback);
}

/**
 * تنظيف النصوص ومنع حقن الأكواد البسيط
 */
export function sanitizeString(str: string): string {
  return str.trim().replace(/[<>]/g, '');
}

/**
 * تنسيق العملة الجزائرية
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('ar-DZ', {
    style: 'currency',
    currency: 'DZD',
    minimumFractionDigits: 2
  }).format(amount);
}
