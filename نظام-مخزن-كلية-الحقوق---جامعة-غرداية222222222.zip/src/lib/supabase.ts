import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isPlaceholderMode = !supabaseUrl || !supabaseAnonKey || supabaseUrl.includes('placeholder.supabase.co');

if (isPlaceholderMode) {
  console.warn('⚠️ تطبيق المخزن يعمل في الوضع المحلي (LocalStorage). لم يتم العثور على مفاتيح Supabase أو المشروع غير معد بشكل كامل.');
} else {
  console.log('✅ تم الاتصال بنجاح بقاعدة بيانات Supabase السحابية.');
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-key'
);
