-- SQL Schema for law.Gh. Stock (Supabase)

-- 1. Categories Table
CREATE TABLE categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Suppliers Table
CREATE TABLE suppliers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  contact_person TEXT,
  email TEXT,
  phone TEXT,
  address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Inventory Table
CREATE TABLE inventory (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  unit TEXT NOT NULL,
  initial_stock NUMERIC DEFAULT 0,
  reorder_level NUMERIC DEFAULT 0,
  location TEXT,
  description TEXT,
  image_url TEXT,
  has_sub_unit BOOLEAN DEFAULT FALSE,
  sub_unit_name TEXT,
  conversion_rate NUMERIC,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Inbound Logs Table
CREATE TABLE inbound_logs (
  id TEXT PRIMARY KEY,
  item_id TEXT REFERENCES inventory(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL,
  quantity NUMERIC NOT NULL,
  unit TEXT NOT NULL,
  date TEXT NOT NULL,
  supplier TEXT NOT NULL,
  notes TEXT,
  department TEXT,
  office_number TEXT,
  is_sub_unit BOOLEAN DEFAULT FALSE,
  conversion_rate NUMERIC,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Outbound Logs Table
CREATE TABLE outbound_logs (
  id TEXT PRIMARY KEY,
  item_id TEXT REFERENCES inventory(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL,
  quantity NUMERIC NOT NULL,
  unit TEXT NOT NULL,
  date TEXT NOT NULL,
  recipient_name TEXT NOT NULL,
  department TEXT NOT NULL,
  office_number TEXT,
  recipient_employee_id TEXT,
  recipient_title TEXT,
  inventory_no TEXT,
  delivery_type TEXT NOT NULL,
  is_sub_unit BOOLEAN DEFAULT FALSE,
  conversion_rate NUMERIC,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Audit Logs Table
CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  timestamp TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS (Row Level Security)
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbound_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbound_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Create Policies (Allow authenticated users to do everything for now)
-- You can harden these later based on roles
CREATE POLICY "Allow authenticated read" ON categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert" ON categories FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Allow authenticated update" ON categories FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Allow authenticated delete" ON categories FOR DELETE TO authenticated USING (true);

CREATE POLICY "Allow authenticated read" ON suppliers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert" ON suppliers FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Allow authenticated update" ON suppliers FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Allow authenticated delete" ON suppliers FOR DELETE TO authenticated USING (true);

CREATE POLICY "Allow authenticated read" ON inventory FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert" ON inventory FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Allow authenticated update" ON inventory FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Allow authenticated delete" ON inventory FOR DELETE TO authenticated USING (true);

CREATE POLICY "Allow authenticated read" ON inbound_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert" ON inbound_logs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Allow authenticated update" ON inbound_logs FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Allow authenticated delete" ON inbound_logs FOR DELETE TO authenticated USING (true);

CREATE POLICY "Allow authenticated read" ON outbound_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert" ON outbound_logs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Allow authenticated update" ON outbound_logs FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Allow authenticated delete" ON outbound_logs FOR DELETE TO authenticated USING (true);

CREATE POLICY "Allow authenticated read" ON audit_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert" ON audit_logs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Allow authenticated update" ON audit_logs FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Allow authenticated delete" ON audit_logs FOR DELETE TO authenticated USING (true);
