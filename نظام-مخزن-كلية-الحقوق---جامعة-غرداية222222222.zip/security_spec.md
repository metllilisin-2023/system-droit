# Security Specification - Law.Gh Stock System

## 1. Data Invariants
- An inventory item must have a positive `currentQty`.
- An inbound/outbound log must reference an existing `itemId`.
- Users must have a role assigned by an existing admin or be bootstrapped.
- `createdAt` and `ownerId` (if applicable) are immutable.
- All IDs must match `^[a-zA-Z0-9_\-]+$`.

## 2. The "Dirty Dozen" (and beyond) Payloads (Denial Expected)
1. **Identity Spoofing**: Creating a log with a different `userId` than the authenticated one.
2. **Privilege Escalation**: Updating own user profile to `role: 'الأمين العام'`.
3. **Ghost Field Injection**: Adding `isVerified: true` to a supplier document.
4. **ID Poisoning**: Using a 1MB string as a document ID.
5. **Relational Orphan**: Creating a log for an `itemId` that doesn't exist.
6. **State Shortcutting**: Manually updating `currentQty` without a corresponding log.
7. **Negative Stock**: Updating an item to have `currentQty: -10`.
8. **PII Leak**: A storekeeper reading another user's profile metadata without admin rights.
9. **Timestamp Manipulation**: Providing a custom `updatedAt` instead of `request.time`.
10. **Shadow Delete**: Deleting an audit log to hide suspicious activity.
11. **Bulk Scrape**: Querying all users without being an admin.
12. **Type Poisoning**: Sending `quantity: "100"` (string) instead of number.
13. **Email Spoofing**: Accessing admin data with an unverified email that matches the admin string.
14. **Immortal Field Mutation**: Attempting to change `itemId` inside an inventory document during update.

## 3. Test Runner Checklist
- [x] `PERMISSION_DENIED` on self-role update.
- [x] `PERMISSION_DENIED` on log creation with mismatched UID.
- [x] `PERMISSION_DENIED` on item qty update without transaction logic.
- [x] `ALLOW` only whitelisted fields during specific updates.
- [ ] `PERMISSION_DENIED` on unverified email writes.
- [ ] `PERMISSION_DENIED` on missing `updatedAt` for updates.
